# JARVIS AI Assistant ProGuard Rules

# Keep Application class
-keep public class com.jarvis.assistant.JarvisApplication { *; }

# Keep Hilt generated classes
-keep class dagger.hilt.** { *; }
-keep class androidx.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }

# Keep Room entities and DAOs
-keep class com.jarvis.assistant.data.local.entity.** { *; }
-keep class com.jarvis.assistant.data.local.db.** { *; }
-keep @androidx.room.Entity class *
-keepclassmembers @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface *
-keep @androidx.room.Database class *

# Keep data classes used for serialization
-keep class com.jarvis.assistant.data.model.** { *; }
-keep class com.jarvis.assistant.domain.model.** { *; }
-keep class com.jarvis.assistant.ai.** { *; }
-keep class com.jarvis.assistant.agent.** { *; }
-keep class com.jarvis.assistant.tools.** { *; }
-keepclassmembers class com.jarvis.assistant.** {
    *** *;
}

# Kotlin serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclassmembers class kotlinx.serialization.** { *** Companion; }

# Keep generic signatures
-keepattributes Signature
-keepattributes Exceptions

# Retrofit
-keep class retrofit2.** { *; }
-keepattributes Signature
-keepattributes Exceptions

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Security Crypto
-keep class androidx.security.crypto.** { *; }

# Material 3
-keep class androidx.compose.material3.** { *; }

# Keep ViewModels
-keep class * extends androidx.lifecycle.ViewModel { *; }

# Remove logs in release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
}
