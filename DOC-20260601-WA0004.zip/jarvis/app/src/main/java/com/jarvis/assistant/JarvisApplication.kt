package com.jarvis.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.jarvis.assistant.voice.TextToSpeechManager
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

/**
 * JARVIS Application class.
 *
 * This is the entry point of the JARVIS AI Assistant application.
 * It initializes core services, notification channels, and dependency injection.
 *
 * @property workerFactory Hilt WorkerFactory for WorkManager integration
 * @property ttsManager Text-to-Speech manager initialized at app startup
 */
@HiltAndroidApp
class JarvisApplication : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    @Inject
    lateinit var ttsManager: TextToSpeechManager

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        initializeServices()
    }

    /**
     * Creates required notification channels for Android O+.
     * JARVIS uses foreground services that require notification channels.
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Voice Assistant channel - used for foreground service
            val voiceChannel = NotificationChannel(
                CHANNEL_VOICE_ASSISTANT,
                getString(R.string.notification_channel_voice),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_voice_desc)
                setShowBadge(false)
                enableVibration(false)
                enableLights(false)
            }

            // Alerts channel - used for reminders and alarms
            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS,
                getString(R.string.notification_channel_alerts),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.notification_channel_alerts_desc)
                setShowBadge(true)
                enableVibration(true)
                enableLights(true)
                lightColor = getColor(R.color.jarvis_blue)
            }

            notificationManager.createNotificationChannel(voiceChannel)
            notificationManager.createNotificationChannel(alertsChannel)
        }
    }

    /**
     * Initializes core application services.
     */
    private fun initializeServices() {
        // Initialize TTS engine early for faster voice responses
        ttsManager.initialize()
    }

    /**
     * Provides WorkManager configuration with Hilt support.
     */
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()

    companion object {
        const val CHANNEL_VOICE_ASSISTANT = "jarvis_voice_assistant"
        const val CHANNEL_ALERTS = "jarvis_alerts"
        const val NOTIFICATION_ID_VOICE_SERVICE = 1001
        const val NOTIFICATION_ID_WAKE_WORD = 1002
    }
}
