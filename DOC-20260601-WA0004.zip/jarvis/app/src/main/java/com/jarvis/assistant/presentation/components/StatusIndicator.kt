package com.jarvis.assistant.presentation.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.presentation.theme.*

/**
 * Status indicator showing JARVIS state.
 */
@Composable
fun StatusIndicator(
    status: JarvisStatus,
    modifier: Modifier = Modifier
) {
    val color = when (status) {
        JarvisStatus.Idle -> TextTertiaryDark
        JarvisStatus.Listening -> StatusListening
        JarvisStatus.Processing -> StatusProcessing
        JarvisStatus.Speaking -> StatusSpeaking
        JarvisStatus.Error -> StatusError
        JarvisStatus.Offline -> TextDisabledDark
    }

    val label = when (status) {
        JarvisStatus.Idle -> "Ready"
        JarvisStatus.Listening -> "Listening..."
        JarvisStatus.Processing -> "Processing..."
        JarvisStatus.Speaking -> "Speaking..."
        JarvisStatus.Error -> "Error"
        JarvisStatus.Offline -> "Offline"
    }

    val infiniteTransition = rememberInfiniteTransition(label = "status_pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(
                    color = if (status == JarvisStatus.Idle) color else color.copy(alpha = alpha),
                    shape = CircleShape
                )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = color
        )
    }
}

/**
 * JARVIS assistant states.
 */
enum class JarvisStatus {
    Idle,
    Listening,
    Processing,
    Speaking,
    Error,
    Offline
}
