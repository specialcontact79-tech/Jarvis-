package com.jarvis.assistant.ai

import com.jarvis.assistant.data.local.prefs.SecurePrefsManager
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.utils.Logger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

/**
 * OpenAI GPT provider implementation.
 */
@Singleton
class OpenAiProvider @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val securePrefsManager: SecurePrefsManager
) : AiProvider {

    private val json = Json { ignoreUnknownKeys = true }

    override val name: String = "openai"

    override val availableModels: List<String> = listOf(
        "gpt-4",
        "gpt-4-turbo",
        "gpt-3.5-turbo"
    )

    override fun isConfigured(): Boolean =
        !securePrefsManager.getOpenAiApiKey().isNullOrBlank()

    override suspend fun validateApiKey(): Boolean {
        val apiKey = securePrefsManager.getOpenAiApiKey() ?: return false
        return try {
            val request = Request.Builder()
                .url("https://api.openai.com/v1/models")
                .header("Authorization", "Bearer $apiKey")
                .get()
                .build()
            okHttpClient.newCall(request).execute().use { response ->
                response.isSuccessful
            }
        } catch (e: Exception) {
            Logger.e(TAG, "API key validation failed", e)
            false
        }
    }

    override fun sendMessage(
        messages: List<ChatMessage>,
        systemPrompt: String,
        tools: List<ToolDefinition>
    ): Flow<AiResponse> = flow {
        val apiKey = securePrefsManager.getOpenAiApiKey()
        if (apiKey.isNullOrBlank()) {
            emit(AiResponse.Error("OpenAI API key not configured"))
            return@flow
        }

        try {
            val openAiTools = if (tools.isNotEmpty()) {
                tools.map { tool ->
                    OpenAiTool(
                        function = OpenAiFunction(
                            name = tool.name,
                            description = tool.description,
                            parameters = tool.parameters?.let {
                                Json.parseToJsonElement(it.toString()).jsonObject
                            }
                        )
                    )
                }
            } else null

            val openAiMessages = buildOpenAiMessages(messages, systemPrompt)

            val requestBody = OpenAiRequest(
                model = "gpt-4",
                messages = openAiMessages,
                tools = openAiTools,
                toolChoice = if (openAiTools != null) "auto" else null
            )

            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .header("Content-Type", "application/json")
                .post(json.encodeToString(requestBody).toRequestBody("application/json".toMediaType()))
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string()
                    Logger.e(TAG, "OpenAI API error: $errorBody")
                    emit(AiResponse.Error("API error: ${response.code}"))
                    return@flow
                }

                val responseBody = response.body?.string()
                    ?: run {
                        emit(AiResponse.Error("Empty response"))
                        return@flow
                    }

                val openAiResponse = json.decodeFromString<OpenAiResponse>(responseBody)

                // Check for API errors
                openAiResponse.error?.let { error ->
                    emit(AiResponse.Error("${error.message} (${error.code ?: ""})"))
                    return@flow
                }

                // Process choices
                val choice = openAiResponse.choices?.firstOrNull()
                val message = choice?.message

                // Check for tool calls
                if (!message?.toolCalls.isNullOrEmpty()) {
                    val toolCalls = message!!.toolCalls!!.map { tc ->
                        ToolCall(
                            id = tc.id,
                            name = tc.function.name,
                            arguments = try {
                                json.decodeFromString<Map<String, String>>(tc.function.arguments)
                            } catch (e: Exception) {
                                mapOf("args" to tc.function.arguments)
                            }
                        )
                    }
                    emit(AiResponse.ToolCallResponse(toolCalls))
                    return@flow
                }

                // Extract text response
                val text = message?.content
                if (!text.isNullOrBlank()) {
                    emit(AiResponse.Complete(text.trim()))
                } else {
                    emit(AiResponse.Error("Empty response from AI"))
                }
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Error in OpenAI request", e)
            emit(AiResponse.Error(e.localizedMessage ?: "Unknown error"))
        }
    }

    private fun buildOpenAiMessages(
        messages: List<ChatMessage>,
        systemPrompt: String
    ): List<OpenAiMessage> {
        val result = mutableListOf<OpenAiMessage>()

        // Add system prompt
        if (systemPrompt.isNotBlank()) {
            result.add(
                OpenAiMessage(
                    role = "system",
                    content = systemPrompt
                )
            )
        }

        // Convert conversation history
        messages.forEach { message ->
            val role = when (message.role) {
                "user" -> "user"
                "assistant" -> "assistant"
                "tool" -> "tool"
                else -> "user"
            }
            result.add(
                OpenAiMessage(
                    role = role,
                    content = message.content
                )
            )
        }

        return result
    }

    companion object {
        private const val TAG = "OpenAiProvider"
    }
}
