package com.jarvis.assistant.tools

import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import com.jarvis.assistant.ai.ToolDefinition
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.putJsonObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tool for media-related functions: camera, share text.
 */
@Singleton
class MediaTool @Inject constructor(
    @ApplicationContext private val context: Context
) : Tool {

    override fun getName(): String = "media"

    override fun getDescription(): String = "Open camera and share content"

    override fun getDefinition(): ToolDefinition = ToolDefinition(
        name = getName(),
        description = getDescription(),
        parameters = buildJsonObject {
            putJsonObject("properties") {
                putJsonObject("action") {
                    put("type", "string")
                    put("description", "Action: camera, share")
                }
                putJsonObject("type") {
                    put("type", "string")
                    put("description", "For camera: photo or video. For share: text type")
                }
                putJsonObject("content") {
                    put("type", "string")
                    put("description", "Content to share (for share action)")
                }
            }
        }
    )

    override suspend fun execute(input: String): String {
        val lower = input.lowercase()

        return when {
            lower.contains("camera") || lower.contains("photo") ||
                    lower.contains("picture") || lower.contains("selfie") ||
                    lower.contains("video") -> {
                val isVideo = lower.contains("video")
                openCamera(isVideo)
            }
            lower.contains("share") -> {
                val content = extractShareContent(input)
                shareText(content)
            }
            else -> "Unknown media command"
        }
    }

    override suspend fun executeWithParams(params: Map<String, String>): String {
        val action = params["action"] ?: "camera"
        val type = params["type"] ?: ""
        val content = params["content"] ?: params["text"] ?: ""

        return when (action.lowercase()) {
            "camera", "photo", "picture" -> openCamera(type == "video")
            "share" -> shareText(content)
            else -> "Unknown action: $action"
        }
    }

    private fun openCamera(isVideo: Boolean): String {
        return try {
            val intent = if (isVideo) {
                Intent(MediaStore.ACTION_VIDEO_CAPTURE)
            } else {
                Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            // Check if camera app is available
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                if (isVideo) "video" else "photo"
            } else {
                // Fallback: open camera app directly
                val cameraIntent = context.packageManager.getLaunchIntentForPackage("com.android.camera2")
                    ?: context.packageManager.getLaunchIntentForPackage("com.google.android.GoogleCamera")
                if (cameraIntent != null) {
                    cameraIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(cameraIntent)
                    if (isVideo) "video" else "photo"
                } else {
                    "Camera app not found"
                }
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to open camera", e)
            "Failed to open camera: ${e.localizedMessage}"
        }
    }

    private fun shareText(content: String): String {
        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, content)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Share via").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            "Share dialog opened"
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to share", e)
            "Failed to share: ${e.localizedMessage}"
        }
    }

    private fun extractShareContent(input: String): String {
        val lower = input.lowercase()
        val prefixes = listOf(
            "share ", "share this ", "share the ", "send this ", "send "
        )
        for (prefix in prefixes) {
            val idx = lower.indexOf(prefix)
            if (idx >= 0) {
                return input.substring(idx + prefix.length).trim()
            }
        }
        return input
    }

    companion object {
        private const val TAG = "MediaTool"
    }
}
