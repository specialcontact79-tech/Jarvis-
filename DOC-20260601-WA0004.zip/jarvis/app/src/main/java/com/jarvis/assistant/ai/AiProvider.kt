package com.jarvis.assistant.ai

import com.jarvis.assistant.domain.model.ChatMessage
import kotlinx.coroutines.flow.Flow

/**
 * Interface for AI providers.
 *
 * Implementations: GeminiProvider, OpenAiProvider
 */
interface AiProvider {

    /**
     * Name of the provider.
     */
    val name: String

    /**
     * Available models for this provider.
     */
    val availableModels: List<String>

    /**
     * Sends messages to the AI and returns the response.
     *
     * @param messages Conversation history
     * @param systemPrompt System instructions
     * @param tools Available tool definitions
     * @return Flow of response chunks or complete response
     */
    fun sendMessage(
        messages: List<ChatMessage>,
        systemPrompt: String,
        tools: List<ToolDefinition> = emptyList()
    ): Flow<AiResponse>

    /**
     * Checks if the provider is configured with a valid API key.
     */
    fun isConfigured(): Boolean

    /**
     * Validates the API key by making a test request.
     */
    suspend fun validateApiKey(): Boolean
}

/**
 * Sealed class representing AI response states.
 */
sealed class AiResponse {
    /**
     * Partial text chunk (for streaming).
     */
    data class Chunk(val text: String) : AiResponse()

    /**
     * Complete response text.
     */
    data class Complete(val text: String) : AiResponse()

    /**
     * Tool call requested by AI.
     */
    data class ToolCallResponse(val toolCalls: List<ToolCall>) : AiResponse()

    /**
     * Error occurred.
     */
    data class Error(val message: String) : AiResponse()
}
