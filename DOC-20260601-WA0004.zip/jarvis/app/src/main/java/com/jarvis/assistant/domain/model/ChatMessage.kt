package com.jarvis.assistant.domain.model

import java.time.Instant
import java.util.UUID

/**
 * Domain model representing a chat message.
 */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val conversationId: String = "",
    val content: String,
    val role: String, // "user", "assistant", "system", "tool"
    val timestamp: Instant = Instant.now(),
    val toolCallsJson: String? = null,
    val toolResultsJson: String? = null,
    val isError: Boolean = false,
    val processingTimeMs: Long? = null
) {
    companion object {
        fun user(content: String) = ChatMessage(
            content = content,
            role = "user"
        )

        fun assistant(content: String) = ChatMessage(
            content = content,
            role = "assistant"
        )

        fun system(content: String) = ChatMessage(
            content = content,
            role = "system"
        )

        fun toolResult(content: String) = ChatMessage(
            content = content,
            role = "tool"
        )
    }
}
