package com.jarvis.assistant.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages runtime permissions for JARVIS.
 *
 * Defines all required permissions and provides checking utilities.
 */
@Singleton
class PermissionManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /**
     * Permission definitions with metadata.
     */
    data class PermissionInfo(
        val permission: String,
        val title: String,
        val description: String,
        val iconRes: Int,
        val requiredFor: String
    )

    /**
     * All permissions that JARVIS may request.
     */
    fun getAllPermissions(): List<PermissionInfo> = listOf(
        PermissionInfo(
            Manifest.permission.RECORD_AUDIO,
            "Microphone",
            "Required for voice recognition and conversations",
            android.R.drawable.ic_btn_speak_now,
            "voice"
        ),
        PermissionInfo(
            Manifest.permission.CAMERA,
            "Camera",
            "Required for camera control and flashlight",
            android.R.drawable.ic_menu_camera,
            "flashlight"
        ),
        PermissionInfo(
            Manifest.permission.READ_CONTACTS,
            "Contacts",
            "Required for making calls and sending messages",
            android.R.drawable.ic_menu_myplaces,
            "calls"
        ),
        PermissionInfo(
            Manifest.permission.CALL_PHONE,
            "Phone",
            "Required for making phone calls",
            android.R.drawable.ic_menu_call,
            "calls"
        ),
        PermissionInfo(
            Manifest.permission.SEND_SMS,
            "SMS",
            "Required for sending text messages",
            android.R.drawable.ic_menu_send,
            "sms"
        ),
        PermissionInfo(
            Manifest.permission.BLUETOOTH_CONNECT,
            "Bluetooth",
            "Required for controlling Bluetooth",
            android.R.drawable.stat_sys_data_bluetooth,
            "bluetooth"
        ),
        PermissionInfo(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                Manifest.permission.POST_NOTIFICATIONS
            } else {
                "android.permission.POST_NOTIFICATIONS"
            },
            "Notifications",
            "Required for foreground service notifications",
            android.R.drawable.ic_popup_reminder,
            "notifications"
        )
    ).filter {
        // Filter out permissions that don't exist on this API level
        try {
            PackageManager.PERMISSION_GRANTED
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Core permissions required for basic functionality.
     */
    fun getCorePermissions(): List<String> = listOf(
        Manifest.permission.RECORD_AUDIO
    )

    /**
     * Permissions for device control features.
     */
    fun getDevicePermissions(): List<String> = listOf(
        Manifest.permission.CAMERA,
        Manifest.permission.BLUETOOTH_CONNECT
    )

    /**
     * Permissions for communication features.
     */
    fun getCommunicationPermissions(): List<String> = listOf(
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS
    )

    /**
     * Permissions for notifications.
     */
    fun getNotificationPermissions(): List<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            listOf(Manifest.permission.POST_NOTIFICATIONS)
        } else emptyList()

    /**
     * Checks if a permission is granted.
     */
    fun isGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) ==
                PackageManager.PERMISSION_GRANTED
    }

    /**
     * Checks if all core permissions are granted.
     */
    fun hasCorePermissions(): Boolean {
        return getCorePermissions().all { isGranted(it) }
    }

    /**
     * Checks if all permissions in a list are granted.
     */
    fun hasPermissions(permissions: List<String>): Boolean {
        return permissions.all { isGranted(it) }
    }

    /**
     * Gets permissions that need to be requested.
     */
    fun getMissingPermissions(permissions: List<String>): List<String> {
        return permissions.filterNot { isGranted(it) }
    }

    /**
     * Gets all missing permissions across all categories.
     */
    fun getAllMissingPermissions(): List<PermissionInfo> {
        val all = getAllPermissions()
        return all.filter { !isGranted(it.permission) }
    }

    /**
     * Maps permission string to human-readable info.
     */
    fun getPermissionInfo(permission: String): PermissionInfo? {
        return getAllPermissions().find { it.permission == permission }
    }
}
