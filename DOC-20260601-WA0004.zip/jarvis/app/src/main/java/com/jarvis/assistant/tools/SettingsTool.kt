package com.jarvis.assistant.tools

import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import com.jarvis.assistant.ai.ToolDefinition
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.putJsonObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tool for controlling device settings: flashlight, bluetooth, wifi, volume, brightness.
 */
@Singleton
class SettingsTool @Inject constructor(
    @ApplicationContext private val context: Context
) : Tool {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager

    private var flashlightOn = false

    override fun getName(): String = "device_settings"

    override fun getDescription(): String = "Control device settings: flashlight, bluetooth, wifi, volume, and brightness"

    override fun getDefinition(): ToolDefinition = ToolDefinition(
        name = getName(),
        description = getDescription(),
        parameters = buildJsonObject {
            putJsonObject("properties") {
                putJsonObject("setting") {
                    put("type", "string")
                    put("description", "Setting to control: flashlight, bluetooth, wifi, volume, or brightness")
                }
                putJsonObject("action") {
                    put("type", "string")
                    put("description", "Action: on, off, toggle, or a number for volume/brightness")
                }
            }
        }
    )

    override suspend fun execute(input: String): String {
        val lower = input.lowercase()

        return when {
            lower.contains("flashlight") || lower.contains("torch") -> {
                val turnOn = !lower.contains("off") && (lower.contains("on") || !flashlightOn)
                controlFlashlight(turnOn)
            }
            lower.contains("bluetooth") -> {
                val turnOn = !lower.contains("off")
                controlBluetooth(turnOn)
            }
            lower.contains("wifi") -> {
                val turnOn = !lower.contains("off")
                controlWifi(turnOn)
            }
            lower.contains("volume") -> {
                val level = extractVolumeLevel(lower)
                setVolume(level)
            }
            lower.contains("brightness") -> {
                val level = extractBrightnessLevel(lower)
                setBrightness(level)
            }
            else -> "Unknown device setting command"
        }
    }

    override suspend fun executeWithParams(params: Map<String, String>): String {
        val setting = params["setting"] ?: params["device"] ?: return "No setting specified"
        val action = params["action"] ?: params["state"] ?: "toggle"

        return when (setting.lowercase()) {
            "flashlight" -> controlFlashlight(action == "on" || action == "true")
            "bluetooth" -> controlBluetooth(action == "on" || action == "true" || action == "enable")
            "wifi" -> controlWifi(action == "on" || action == "true" || action == "enable")
            "volume" -> {
                val level = action.toIntOrNull() ?: 50
                setVolume(level)
            }
            "brightness" -> {
                val level = action.toIntOrNull() ?: 50
                setBrightness(level)
            }
            else -> "Unknown setting: $setting"
        }
    }

    private fun controlFlashlight(turnOn: Boolean): String {
        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull()
                ?: return "Flashlight not available"
            cameraManager.setTorchMode(cameraId, turnOn)
            flashlightOn = turnOn
            if (turnOn) "on" else "off"
        } catch (e: Exception) {
            Logger.e(TAG, "Flashlight error", e)
            "Failed to control flashlight: ${e.localizedMessage}"
        }
    }

    private fun controlBluetooth(turnOn: Boolean): String {
        return try {
            val adapter = bluetoothManager.adapter ?: return "Bluetooth not available"
            if (turnOn) {
                if (!adapter.isEnabled) {
                    val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                }
            } else {
                if (adapter.isEnabled) {
                    adapter.disable()
                }
            }
            if (turnOn) "on" else "off"
        } catch (e: SecurityException) {
            Logger.e(TAG, "Bluetooth permission denied", e)
            "Bluetooth permission required. Please grant Bluetooth permission in settings."
        } catch (e: Exception) {
            Logger.e(TAG, "Bluetooth error", e)
            "Failed to control Bluetooth: ${e.localizedMessage}"
        }
    }

    private fun controlWifi(turnOn: Boolean): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ requires system app or Settings Panel
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                "Opening WiFi settings (Android 10+ requires manual control)"
            } else {
                @Suppress("DEPRECATION")
                wifiManager.isWifiEnabled = turnOn
                if (turnOn) "on" else "off"
            }
        } catch (e: SecurityException) {
            Logger.e(TAG, "WiFi permission denied", e)
            "WiFi permission required"
        } catch (e: Exception) {
            Logger.e(TAG, "WiFi error", e)
            "Failed to control WiFi: ${e.localizedMessage}"
        }
    }

    private fun setVolume(level: Int): String {
        return try {
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val targetVolume = (level / 100.0 * maxVolume).toInt().coerceIn(0, maxVolume)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVolume, AudioManager.FLAG_SHOW_UI)
            "$level%"
        } catch (e: Exception) {
            Logger.e(TAG, "Volume error", e)
            "Failed to set volume: ${e.localizedMessage}"
        }
    }

    private fun setBrightness(level: Int): String {
        return try {
            val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            "$level% (Opening brightness settings)"
        } catch (e: Exception) {
            Logger.e(TAG, "Brightness error", e)
            "Failed to set brightness: ${e.localizedMessage}"
        }
    }

    private fun extractVolumeLevel(input: String): Int {
        val regex = Regex("(\\d+)%?")
        val match = regex.find(input)
        return match?.groupValues?.get(1)?.toIntOrNull() ?: 50
    }

    private fun extractBrightnessLevel(input: String): Int {
        val regex = Regex("(\\d+)%?")
        val match = regex.find(input)
        return match?.groupValues?.get(1)?.toIntOrNull() ?: 50
    }

    companion object {
        private const val TAG = "SettingsTool"
    }
}
