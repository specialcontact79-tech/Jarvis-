package com.jarvis.assistant.data.local.prefs

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Secure preferences manager for storing sensitive data.
 *
 * Uses EncryptedSharedPreferences to securely store:
 * - API keys for AI providers
 * - User authentication tokens
 * - Other sensitive configuration
 *
 * @property context Application context for creating encrypted prefs
 */
@Singleton
class SecurePrefsManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    private val securePrefs: SharedPreferences by lazy {
        EncryptedSharedPreferences.create(
            context,
            PREFS_FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private val _geminiApiKey = MutableStateFlow(getGeminiApiKey())
    val geminiApiKey: StateFlow<String?> = _geminiApiKey.asStateFlow()

    private val _openAiApiKey = MutableStateFlow(getOpenAiApiKey())
    val openAiApiKey: StateFlow<String?> = _openAiApiKey.asStateFlow()

    /**
     * Stores the Gemini API key securely.
     */
    fun saveGeminiApiKey(apiKey: String) {
        securePrefs.edit()
            .putString(KEY_GEMINI_API_KEY, apiKey.trim())
            .apply()
        _geminiApiKey.value = apiKey.trim()
    }

    /**
     * Retrieves the Gemini API key.
     */
    fun getGeminiApiKey(): String? {
        val key = securePrefs.getString(KEY_GEMINI_API_KEY, null)
        return if (key.isNullOrBlank()) null else key
    }

    /**
     * Stores the OpenAI API key securely.
     */
    fun saveOpenAiApiKey(apiKey: String) {
        securePrefs.edit()
            .putString(KEY_OPENAI_API_KEY, apiKey.trim())
            .apply()
        _openAiApiKey.value = apiKey.trim()
    }

    /**
     * Retrieves the OpenAI API key.
     */
    fun getOpenAiApiKey(): String? {
        val key = securePrefs.getString(KEY_OPENAI_API_KEY, null)
        return if (key.isNullOrBlank()) null else key
    }

    /**
     * Clears all stored API keys.
     */
    fun clearAllApiKeys() {
        securePrefs.edit()
            .remove(KEY_GEMINI_API_KEY)
            .remove(KEY_OPENAI_API_KEY)
            .apply()
        _geminiApiKey.value = null
        _openAiApiKey.value = null
    }

    /**
     * Checks if any API key is configured.
     */
    fun hasAnyApiKey(): Boolean =
        !getGeminiApiKey().isNullOrBlank() || !getOpenAiApiKey().isNullOrBlank()

    /**
     * Clears all secure preferences.
     */
    fun clearAll() {
        securePrefs.edit().clear().apply()
        _geminiApiKey.value = null
        _openAiApiKey.value = null
    }

    companion object {
        private const val PREFS_FILE_NAME = "jarvis_secure_prefs"
        private const val KEY_GEMINI_API_KEY = "gemini_api_key"
        private const val KEY_OPENAI_API_KEY = "openai_api_key"
    }
}
