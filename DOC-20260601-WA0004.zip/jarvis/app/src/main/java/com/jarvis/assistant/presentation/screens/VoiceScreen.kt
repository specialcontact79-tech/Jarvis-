package com.jarvis.assistant.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.presentation.components.*
import com.jarvis.assistant.presentation.theme.*
import com.jarvis.assistant.presentation.viewmodel.VoiceViewModel

/**
 * Voice interaction screen.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceScreen(
    viewModel: VoiceViewModel,
    conversationId: String,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val transcription by viewModel.transcription.collectAsState()

    LaunchedEffect(conversationId) {
        if (conversationId.isNotBlank()) {
            viewModel.startListening(conversationId)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Voice Assistant") },
                navigationIcon = {
                    IconButton(onClick = {
                        viewModel.stopListening()
                        onNavigateBack()
                    }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Status
            StatusIndicator(status = uiState.status)

            Spacer(modifier = Modifier.weight(1f))

            // Voice Orb
            VoiceOrb(
                isListening = uiState.status == JarvisStatus.Listening,
                isProcessing = uiState.status == JarvisStatus.Processing,
                isSpeaking = uiState.status == JarvisStatus.Speaking,
                onClick = {
                    if (uiState.status == JarvisStatus.Listening) {
                        viewModel.stopListening()
                    } else {
                        viewModel.startListening(conversationId)
                    }
                },
                modifier = Modifier.size(250.dp)
            )

            Spacer(modifier = Modifier.weight(1f))

            // Transcript
            if (transcription.isNotBlank()) {
                Text(
                    text = "\"$transcription\"",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Response
            if (uiState.response.isNotBlank()) {
                ResponseCard(response = uiState.response)
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Error
            if (uiState.errorMessage != null) {
                Text(
                    text = uiState.errorMessage ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = JarvisRed,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Tool Calls
            uiState.toolCalls.forEach { toolName ->
                ToolCallCard(
                    toolName = toolName,
                    isExecuting = uiState.status == JarvisStatus.Processing,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = { viewModel.startListening(conversationId) },
                    enabled = uiState.status != JarvisStatus.Listening,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = JarvisBlue
                    )
                ) {
                    Text("Listen")
                }
                Button(
                    onClick = { viewModel.stopListening() },
                    enabled = uiState.status == JarvisStatus.Listening,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = JarvisRed
                    )
                ) {
                    Text("Stop")
                }
            }
        }
    }
}

@Composable
private fun ResponseCard(response: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = SurfaceCard
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            JarvisBlue.copy(alpha = 0.1f),
                            JarvisPurple.copy(alpha = 0.05f)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Text(
                text = response,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
