package com.jarvis.assistant.data.local.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.jarvis.assistant.data.local.entity.ConversationEntity
import com.jarvis.assistant.data.local.entity.MessageEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for conversations and messages.
 */
@Dao
interface ConversationDao {

    // ==================== CONVERSATIONS ====================

    @Query("SELECT * FROM conversations ORDER BY updated_at DESC")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE is_active = 1 ORDER BY updated_at DESC")
    fun getActiveConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :conversationId")
    suspend fun getConversationById(conversationId: String): ConversationEntity?

    @Query("SELECT * FROM conversations WHERE id = :conversationId")
    fun observeConversation(conversationId: String): Flow<ConversationEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: ConversationEntity)

    @Update
    suspend fun updateConversation(conversation: ConversationEntity)

    @Query("UPDATE conversations SET title = :title, updated_at = :timestamp WHERE id = :conversationId")
    suspend fun updateConversationTitle(conversationId: String, title: String, timestamp: java.time.Instant)

    @Query("UPDATE conversations SET message_count = message_count + 1, updated_at = :timestamp WHERE id = :conversationId")
    suspend fun incrementMessageCount(conversationId: String, timestamp: java.time.Instant)

    @Query("UPDATE conversations SET is_active = 0 WHERE id = :conversationId")
    suspend fun archiveConversation(conversationId: String)

    @Query("UPDATE conversations SET is_active = 1 WHERE id = :conversationId")
    suspend fun restoreConversation(conversationId: String)

    @Delete
    suspend fun deleteConversation(conversation: ConversationEntity)

    @Query("DELETE FROM conversations WHERE id = :conversationId")
    suspend fun deleteConversationById(conversationId: String)

    @Query("DELETE FROM conversations WHERE is_active = 0")
    suspend fun deleteArchivedConversations()

    @Query("SELECT COUNT(*) FROM conversations")
    suspend fun getConversationCount(): Int

    // ==================== MESSAGES ====================

    @Query("SELECT * FROM messages WHERE conversation_id = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversation_id = :conversationId ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentMessages(conversationId: String, limit: Int): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE conversation_id = :conversationId ORDER BY timestamp ASC")
    suspend fun getMessagesSync(conversationId: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<MessageEntity>)

    @Update
    suspend fun updateMessage(message: MessageEntity)

    @Query("UPDATE messages SET is_error = :isError WHERE id = :messageId")
    suspend fun updateMessageError(messageId: String, isError: Boolean)

    @Delete
    suspend fun deleteMessage(message: MessageEntity)

    @Query("DELETE FROM messages WHERE conversation_id = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: String)

    // ==================== TRANSACTIONS ====================

    @Transaction
    suspend fun insertMessageAndUpdateConversation(
        message: MessageEntity,
        conversationId: String,
        timestamp: java.time.Instant
    ) {
        insertMessage(message)
        incrementMessageCount(conversationId, timestamp)
    }

    @Transaction
    suspend fun deleteConversationWithMessages(conversation: ConversationEntity) {
        deleteMessagesForConversation(conversation.id)
        deleteConversation(conversation)
    }
}
