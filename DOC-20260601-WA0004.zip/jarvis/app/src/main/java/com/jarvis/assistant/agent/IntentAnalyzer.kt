package com.jarvis.assistant.agent

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Analyzes user messages to determine intent.
 *
 * Uses keyword matching and pattern recognition to classify user intent.
 * This enables direct tool execution for common commands without AI round-trip.
 */
@Singleton
class IntentAnalyzer @Inject constructor() {

    /**
     * Analyzes a message and returns the detected intent.
     */
    fun analyze(message: String): Intent {
        val lowerMessage = message.lowercase().trim()

        // Check each intent pattern
        for ((intentType, patterns) in INTENT_PATTERNS) {
            for (pattern in patterns) {
                if (lowerMessage.contains(pattern)) {
                    return Intent(
                        type = intentType,
                        confidence = 0.85f,
                        rawMessage = message,
                        extractedParams = extractParams(lowerMessage, intentType)
                    )
                }
            }
        }

        // Default to conversational
        return Intent(
            type = "conversational",
            confidence = 0.5f,
            rawMessage = message,
            extractedParams = emptyMap()
        )
    }

    private fun extractParams(message: String, intentType: String): Map<String, String> {
        val params = mutableMapOf<String, String>()

        when (intentType) {
            "open_app" -> {
                val appName = extractAfterKeywords(message,
                    listOf("open", "launch", "start", "run"))
                if (appName != null) params["app_name"] = appName
            }
            "open_settings" -> {
                val settingName = extractAfterKeywords(message,
                    listOf("settings", "setting"))
                if (settingName != null) params["setting_name"] = settingName
            }
            "open_website" -> {
                val url = extractUrl(message)
                if (url != null) params["url"] = url
            }
            "control_flashlight" -> {
                params["state"] = if (message.contains("on")) "on" else "off"
            }
            "control_bluetooth" -> {
                params["state"] = if (message.contains("on")) "on" else "off"
            }
            "control_wifi" -> {
                params["state"] = if (message.contains("on")) "on" else "off"
            }
            "set_volume" -> {
                val level = extractNumber(message)
                if (level != null) params["level"] = level.toString()
            }
            "set_brightness" -> {
                val level = extractNumber(message)
                if (level != null) params["level"] = level.toString()
            }
            "set_alarm" -> {
                val time = extractTime(message)
                if (time != null) params["time"] = time
            }
            "set_reminder" -> {
                val reminderText = extractAfterKeywords(message,
                    listOf("remind me to", "reminder to", "remind me"))
                if (reminderText != null) params["text"] = reminderText
            }
            "make_call" -> {
                val contact = extractAfterKeywords(message,
                    listOf("call", "phone", "dial"))
                if (contact != null) params["contact"] = contact
            }
            "send_sms" -> {
                val parts = message.split(Regex("(?:to|for)"), limit = 2)
                if (parts.size > 1) {
                    params["contact"] = parts[1].trim()
                    params["message"] = parts[0].trim()
                }
            }
        }

        return params
    }

    private fun extractAfterKeywords(message: String, keywords: List<String>): String? {
        for (keyword in keywords) {
            val index = message.indexOf(keyword)
            if (index >= 0) {
                val after = message.substring(index + keyword.length).trim()
                if (after.isNotBlank()) return after
            }
        }
        return null
    }

    private fun extractUrl(message: String): String? {
        val urlRegex = Regex("(?:https?://)?(?:www\\.)?([a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})")
        return urlRegex.find(message)?.value
    }

    private fun extractNumber(message: String): Int? {
        val numberRegex = Regex("\\d+")
        return numberRegex.find(message)?.value?.toIntOrNull()
    }

    private fun extractTime(message: String): String? {
        // Match patterns like "7 AM", "14:30", "3:45 PM"
        val timeRegex = Regex("(\\d{1,2}):?(\\d{2})?\\s*(AM|PM|am|pm)?")
        return timeRegex.find(message)?.value
    }

    /**
     * Represents a detected intent.
     */
    data class Intent(
        val type: String,
        val confidence: Float,
        val rawMessage: String,
        val extractedParams: Map<String, String>
    )

    companion object {
        private val INTENT_PATTERNS = mapOf(
            "open_app" to listOf(
                "open app", "open the app", "launch app", "launch the app",
                "start app", "start the app", "open ", "launch ", "start "
            ),
            "open_settings" to listOf(
                "open settings", "settings", "go to settings", "show settings",
                "wifi settings", "bluetooth settings", "display settings"
            ),
            "open_website" to listOf(
                "open website", "go to website", "visit", "browse to",
                "go to ", "open google", "open youtube", "open facebook"
            ),
            "control_flashlight" to listOf(
                "turn on flashlight", "turn off flashlight", "flashlight on",
                "flashlight off", "enable flashlight", "disable flashlight",
                "torch on", "torch off"
            ),
            "control_bluetooth" to listOf(
                "turn on bluetooth", "turn off bluetooth", "bluetooth on",
                "bluetooth off", "enable bluetooth", "disable bluetooth"
            ),
            "control_wifi" to listOf(
                "turn on wifi", "turn off wifi", "wifi on", "wifi off",
                "enable wifi", "disable wifi"
            ),
            "set_volume" to listOf(
                "set volume", "volume to", "volume up", "volume down",
                "increase volume", "decrease volume", "lower volume", "raise volume"
            ),
            "set_brightness" to listOf(
                "set brightness", "brightness to", "screen brightness"
            ),
            "set_alarm" to listOf(
                "set alarm", "wake me up at", "alarm for", "create alarm"
            ),
            "set_reminder" to listOf(
                "remind me", "set reminder", "create reminder"
            ),
            "make_call" to listOf(
                "call ", "phone ", "dial ", "call the"
            ),
            "send_sms" to listOf(
                "send message", "send sms", "text ", "message to"
            ),
            "open_camera" to listOf(
                "open camera", "take photo", "take picture", "launch camera",
                "camera app", "selfie"
            ),
            "share_text" to listOf(
                "share ", "send this", "share this"
            )
        )
    }
}
