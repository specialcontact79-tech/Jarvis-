package com.jarvis.assistant.agent

import com.jarvis.assistant.tools.Tool
import com.jarvis.assistant.tools.ToolRegistry
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Selects the appropriate tool based on detected intent.
 */
@Singleton
class ToolSelector @Inject constructor(
    private val toolRegistry: ToolRegistry
) {

    /**
     * Selects the best tool for the given intent.
     *
     * @return The matching tool, or null if no direct match
     */
    fun selectTool(intent: IntentAnalyzer.Intent): Tool? {
        return when (intent.type) {
            "open_app" -> toolRegistry.findTool("open_app")
            "open_settings" -> toolRegistry.findTool("open_settings")
            "open_website" -> toolRegistry.findTool("open_website")
            "control_flashlight" -> toolRegistry.findTool("flashlight")
            "control_bluetooth" -> toolRegistry.findTool("bluetooth")
            "control_wifi" -> toolRegistry.findTool("wifi")
            "set_volume" -> toolRegistry.findTool("volume")
            "set_brightness" -> toolRegistry.findTool("brightness")
            "set_alarm" -> toolRegistry.findTool("alarm")
            "set_reminder" -> toolRegistry.findTool("reminder")
            "make_call" -> toolRegistry.findTool("call")
            "send_sms" -> toolRegistry.findTool("sms")
            "open_camera" -> toolRegistry.findTool("camera")
            "share_text" -> toolRegistry.findTool("share")
            else -> null
        }
    }

    /**
     * Selects multiple tools that might be needed.
     */
    fun selectTools(intents: List<IntentAnalyzer.Intent>): List<Tool> {
        return intents.mapNotNull { selectTool(it) }.distinctBy { it.getName() }
    }
}
