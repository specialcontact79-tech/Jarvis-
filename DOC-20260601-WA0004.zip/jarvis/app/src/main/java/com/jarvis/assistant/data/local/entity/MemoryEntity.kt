package com.jarvis.assistant.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.Instant

/**
 * Entity representing a stored memory/fact about the user or context.
 */
@Entity(
    tableName = "memories",
    indices = [
        Index("category"),
        Index("memory_type"),
        Index("created_at")
    ]
)
data class MemoryEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "content")
    val content: String,

    @ColumnInfo(name = "category")
    val category: String, // "user_preference", "fact", "context", "reminder"

    @ColumnInfo(name = "memory_type")
    val memoryType: String, // "short_term", "long_term"

    @ColumnInfo(name = "key_topics")
    val keyTopics: List<String> = emptyList(),

    @ColumnInfo(name = "source_conversation_id")
    val sourceConversationId: String? = null,

    @ColumnInfo(name = "confidence_score")
    val confidenceScore: Float = 1.0f,

    @ColumnInfo(name = "access_count")
    val accessCount: Int = 0,

    @ColumnInfo(name = "last_accessed_at")
    val lastAccessedAt: Instant? = null,

    @ColumnInfo(name = "created_at")
    val createdAt: Instant,

    @ColumnInfo(name = "expires_at")
    val expiresAt: Instant? = null,

    @ColumnInfo(name = "is_active")
    val isActive: Boolean = true
)
