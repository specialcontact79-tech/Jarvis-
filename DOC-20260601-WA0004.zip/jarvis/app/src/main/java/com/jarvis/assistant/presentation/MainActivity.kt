package com.jarvis.assistant.presentation

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.jarvis.assistant.permissions.PermissionManager
import com.jarvis.assistant.presentation.navigation.NavRoutes
import com.jarvis.assistant.presentation.screens.*
import com.jarvis.assistant.presentation.theme.JARVISTheme
import com.jarvis.assistant.presentation.viewmodel.*
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Main activity for JARVIS AI Assistant.
 *
 * Sets up the Compose UI with navigation and handles the splash screen.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var permissionManager: PermissionManager

    private val homeViewModel: HomeViewModel by viewModels()
    private val voiceViewModel: VoiceViewModel by viewModels()
    private val memoryViewModel: MemoryViewModel by viewModels()
    private val settingsViewModel: SettingsViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        splashScreen.setKeepOnScreenCondition { false }

        setContent {
            JARVISTheme {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                // Check for wake word detection
                val wakeWordDetected = intent?.getBooleanExtra(
                    com.jarvis.assistant.services.WakeWordService.EXTRA_WAKE_WORD_DETECTED, false
                ) ?: false

                Scaffold(
                    bottomBar = {
                        // Only show bottom bar on main screens
                        if (shouldShowBottomBar(currentDestination?.route)) {
                            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                                bottomNavItems.forEach { item ->
                                    val selected = currentDestination?.hierarchy?.any {
                                        it.route == item.route
                                    } == true

                                    NavigationBarItem(
                                        icon = { Icon(item.icon, contentDescription = item.label) },
                                        label = { Text(item.label) },
                                        selected = selected,
                                        onClick = {
                                            navController.navigate(item.route) {
                                                popUpTo(navController.graph.findStartDestination().id) {
                                                    saveState = true
                                                }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = MaterialTheme.colorScheme.primary,
                                            selectedTextColor = MaterialTheme.colorScheme.primary,
                                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                        )
                                    )
                                }
                            }
                        }
                    }
                ) { paddingValues ->
                    NavHost(
                        navController = navController,
                        startDestination = NavRoutes.Splash.route,
                        modifier = Modifier.padding(paddingValues),
                        enterTransition = { fadeIn(animationSpec = tween(300)) },
                        exitTransition = { fadeOut(animationSpec = tween(300)) },
                        popEnterTransition = { fadeIn(animationSpec = tween(300)) },
                        popExitTransition = { fadeOut(animationSpec = tween(300)) }
                    ) {
                        // Splash
                        composable(NavRoutes.Splash.route) {
                            SplashScreen(
                                onNavigateToHome = {
                                    navController.navigate(NavRoutes.Home.route) {
                                        popUpTo(NavRoutes.Splash.route) { inclusive = true }
                                    }
                                }
                            )
                        }

                        // Home
                        composable(NavRoutes.Home.route) {
                            HomeScreen(
                                viewModel = homeViewModel,
                                onNavigateToVoice = { conversationId ->
                                    navController.navigate("voice/$conversationId")
                                },
                                onNavigateToChat = { conversationId ->
                                    navController.navigate(NavRoutes.Chat.createRoute(conversationId))
                                },
                                onNavigateToSettings = {
                                    navController.navigate(NavRoutes.Settings.route)
                                },
                                onNavigateToPermissions = {
                                    navController.navigate(NavRoutes.Permissions.route)
                                }
                            )
                        }

                        // Voice
                        composable("voice/{conversationId}") { backStackEntry ->
                            val conversationId = backStackEntry.arguments?.getString("conversationId") ?: ""
                            VoiceScreen(
                                viewModel = voiceViewModel,
                                conversationId = conversationId,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // Chat
                        composable(NavRoutes.Chat.route) { backStackEntry ->
                            val chatViewModel: ChatViewModel by viewModels()
                            ChatScreen(
                                viewModel = chatViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // Memory
                        composable(NavRoutes.Memory.route) {
                            MemoryScreen(viewModel = memoryViewModel)
                        }

                        // Settings
                        composable(NavRoutes.Settings.route) {
                            SettingsScreen(viewModel = settingsViewModel)
                        }

                        // Permissions
                        composable(NavRoutes.Permissions.route) {
                            PermissionsScreen(
                                permissionManager = permissionManager,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                    }

                    // Handle wake word navigation
                    LaunchedEffect(wakeWordDetected) {
                        if (wakeWordDetected) {
                            homeViewModel.createConversation { id ->
                                navController.navigate("voice/$id")
                            }
                        }
                    }
                }
            }
        }
    }

    private fun shouldShowBottomBar(route: String?): Boolean {
        return route in listOf(
            NavRoutes.Home.route,
            NavRoutes.Memory.route,
            NavRoutes.Settings.route,
            "voice/{conversationId}"
        ) || route?.startsWith("voice/") == true
    }

    data class BottomNavItem(
        val route: String,
        val icon: ImageVector,
        val label: String
    )

    companion object {
        val bottomNavItems = listOf(
            BottomNavItem(NavRoutes.Home.route, Icons.Default.Home, "Home"),
            BottomNavItem("voice/quick", Icons.Default.Mic, "Voice"),
            BottomNavItem(NavRoutes.Memory.route, Icons.Default.Menu, "Memory"),
            BottomNavItem(NavRoutes.Settings.route, Icons.Default.Settings, "Settings")
        )
    }
}
