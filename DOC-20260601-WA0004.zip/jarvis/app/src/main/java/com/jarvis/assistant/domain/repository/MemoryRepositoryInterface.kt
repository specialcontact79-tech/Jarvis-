package com.jarvis.assistant.domain.repository

import com.jarvis.assistant.domain.model.Memory
import kotlinx.coroutines.flow.Flow

/**
 * Interface for memory repository operations.
 */
interface MemoryRepositoryInterface {

    fun getAllMemories(): Flow<List<Memory>>

    fun getShortTermMemories(): Flow<List<Memory>>

    fun getLongTermMemories(): Flow<List<Memory>>

    suspend fun getMemoryById(memoryId: String): Memory?

    suspend fun searchMemories(query: String): List<Memory>

    suspend fun addMemory(memory: Memory): String

    suspend fun addMemories(memories: List<Memory>)

    suspend fun updateMemory(memory: Memory)

    suspend fun deleteMemory(memoryId: String)

    suspend fun recordAccess(memoryId: String)

    suspend fun cleanupExpiredMemories()

    suspend fun getMemoryCount(): Int
}
