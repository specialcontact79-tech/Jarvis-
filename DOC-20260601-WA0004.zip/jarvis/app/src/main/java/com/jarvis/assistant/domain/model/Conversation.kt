package com.jarvis.assistant.domain.model

import java.time.Instant

/**
 * Domain model representing a conversation.
 */
data class Conversation(
    val id: String,
    val title: String,
    val createdAt: Instant,
    val updatedAt: Instant,
    val isActive: Boolean = true,
    val messageCount: Int = 0,
    val contextSummary: String? = null
)
