package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.jarvis.assistant.utils.Logger
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages speech-to-text recognition.
 *
 * Provides continuous listening capabilities with state management.
 */
@Singleton
class SpeechRecognizerManager @Inject constructor(
    private val context: Context
) {

    private var speechRecognizer: SpeechRecognizer? = null

    private val _recognitionState = MutableStateFlow<RecognitionState>(RecognitionState.Idle)
    val recognitionState: StateFlow<RecognitionState> = _recognitionState.asStateFlow()

    private val _transcription = MutableStateFlow("")
    val transcription: StateFlow<String> = _transcription.asStateFlow()

    /**
     * Recognition states.
     */
    sealed class RecognitionState {
        data object Idle : RecognitionState()
        data object Listening : RecognitionState()
        data object Processing : RecognitionState()
        data class Result(val text: String, isFinal: Boolean) : RecognitionState()
        data class Error(val errorCode: Int, val message: String) : RecognitionState()
    }

    /**
     * Checks if speech recognition is available.
     */
    fun isAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    /**
     * Starts listening for speech and returns results as a Flow.
     */
    fun startListening(language: String = "en-US"): Flow<RecognitionResult> = callbackFlow {
        _recognitionState.value = RecognitionState.Listening
        _transcription.value = ""

        if (!isAvailable()) {
            trySend(RecognitionResult.Error(SpeechRecognizer.ERROR_CLIENT, "Speech recognition not available"))
            close()
            return@callbackFlow
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    Logger.i(TAG, "Ready for speech")
                    _recognitionState.value = RecognitionState.Listening
                }

                override fun onBeginningOfSpeech() {
                    Logger.i(TAG, "Speech began")
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // Volume level change - can be used for visual feedback
                }

                override fun onBufferReceived(buffer: ByteArray?) {
                    // Audio buffer received
                }

                override fun onEndOfSpeech() {
                    Logger.i(TAG, "Speech ended")
                    _recognitionState.value = RecognitionState.Processing
                }

                override fun onError(error: Int) {
                    val message = getErrorMessage(error)
                    Logger.e(TAG, "Speech recognition error: $message (code: $error)")
                    _recognitionState.value = RecognitionState.Error(error, message)
                    trySend(RecognitionResult.Error(error, message))
                    close()
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val text = matches[0]
                        Logger.i(TAG, "Speech result: $text")
                        _transcription.value = text
                        _recognitionState.value = RecognitionState.Result(text, isFinal = true)
                        trySend(RecognitionResult.Success(text, isFinal = true))
                    }
                    close()
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val text = matches[0]
                        _transcription.value = text
                        _recognitionState.value = RecognitionState.Result(text, isFinal = false)
                        trySend(RecognitionResult.Success(text, isFinal = false))
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {
                    // Unused
                }
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            }

            startListening(intent)
        }

        awaitClose {
            stopListening()
        }
    }

    /**
     * Stops listening.
     */
    fun stopListening() {
        speechRecognizer?.apply {
            stopListening()
            destroy()
        }
        speechRecognizer = null
        _recognitionState.value = RecognitionState.Idle
    }

    /**
     * Destroys the speech recognizer.
     */
    fun destroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun getErrorMessage(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
            SpeechRecognizer.ERROR_CLIENT -> "Client side error"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
            SpeechRecognizer.ERROR_NETWORK -> "Network error"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech match found"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy"
            SpeechRecognizer.ERROR_SERVER -> "Server error"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
            else -> "Unknown error: $errorCode"
        }
    }

    /**
     * Recognition result sealed class.
     */
    sealed class RecognitionResult {
        data class Success(val text: String, val isFinal: Boolean) : RecognitionResult()
        data class Error(val errorCode: Int, val message: String) : RecognitionResult()
    }

    companion object {
        private const val TAG = "SpeechRecognizerManager"
    }
}
