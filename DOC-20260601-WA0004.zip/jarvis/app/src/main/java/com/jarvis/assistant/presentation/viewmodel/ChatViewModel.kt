package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.repository.ConversationRepositoryInterface
import com.jarvis.assistant.domain.usecase.SendMessageUseCase
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Chat screen.
 */
@HiltViewModel
class ChatViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val conversationRepository: ConversationRepositoryInterface,
    private val sendMessageUseCase: SendMessageUseCase
) : ViewModel() {

    private val conversationId: String = savedStateHandle.get<String>("conversationId")
        ?: throw IllegalArgumentException("conversationId required")

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    val messages: StateFlow<List<ChatMessage>> =
        conversationRepository.getMessagesForConversation(conversationId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun sendMessage(content: String) {
        if (content.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            sendMessageUseCase(conversationId, content).collect { result ->
                when (result) {
                    is SendMessageUseCase.MessageResult.Loading -> {
                        _uiState.update { it.copy(isLoading = true) }
                    }
                    is SendMessageUseCase.MessageResult.Success -> {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                currentResponse = result.message.content,
                                activeToolCalls = result.toolCalls
                            )
                        }
                    }
                    is SendMessageUseCase.MessageResult.Error -> {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                error = result.message
                            )
                        }
                    }
                }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    data class ChatUiState(
        val isLoading: Boolean = false,
        val currentResponse: String = "",
        val activeToolCalls: List<String> = emptyList(),
        val error: String? = null
    )

    companion object {
        private const val TAG = "ChatViewModel"
    }
}
