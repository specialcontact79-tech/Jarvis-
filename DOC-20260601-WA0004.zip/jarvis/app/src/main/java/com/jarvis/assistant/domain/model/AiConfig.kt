package com.jarvis.assistant.domain.model

/**
 * Configuration for AI provider.
 */
data class AiConfig(
    val provider: String,
    val geminiApiKey: String?,
    val openAiApiKey: String?,
    val model: String
) {
    /**
     * Checks if the configured provider has a valid API key.
     */
    fun hasValidKey(): Boolean = when (provider) {
        "gemini" -> !geminiApiKey.isNullOrBlank()
        "openai" -> !openAiApiKey.isNullOrBlank()
        else -> false
    }

    /**
     * Gets the active API key based on the provider.
     */
    fun getActiveKey(): String? = when (provider) {
        "gemini" -> geminiApiKey
        "openai" -> openAiApiKey
        else -> null
    }
}
