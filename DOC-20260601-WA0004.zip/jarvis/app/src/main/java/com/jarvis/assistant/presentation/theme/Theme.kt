package com.jarvis.assistant.presentation.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = JarvisBlue,
    onPrimary = SurfaceDark,
    primaryContainer = JarvisBlueGlow,
    onPrimaryContainer = JarvisBlue,
    secondary = JarvisPurple,
    onSecondary = Color.White,
    secondaryContainer = JarvisPurple.copy(alpha = 0.2f),
    onSecondaryContainer = JarvisPurpleLight,
    tertiary = JarvisTeal,
    onTertiary = SurfaceDark,
    background = SurfaceDark,
    onBackground = TextPrimaryDark,
    surface = SurfaceDarkElevated,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceDarkOverlay,
    onSurfaceVariant = TextSecondaryDark,
    error = JarvisRed,
    onError = Color.White,
    outline = DividerDark
)

private val LightColorScheme = lightColorScheme(
    primary = JarvisBlueDark,
    onPrimary = Color.White,
    primaryContainer = JarvisBlue.copy(alpha = 0.15f),
    onPrimaryContainer = JarvisBlueDark,
    secondary = JarvisPurpleDark,
    onSecondary = Color.White,
    secondaryContainer = JarvisPurple.copy(alpha = 0.15f),
    onSecondaryContainer = JarvisPurpleDark,
    tertiary = JarvisTeal,
    onTertiary = Color.White,
    background = SurfaceLight,
    onBackground = TextPrimaryLight,
    surface = SurfaceLightElevated,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceLightCard,
    onSurfaceVariant = TextSecondaryLight,
    error = JarvisRed,
    onError = Color.White,
    outline = DividerLight
)

@Composable
fun JARVISTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
