package com.jarvis.assistant.tools

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.CalendarContract
import com.jarvis.assistant.ai.ToolDefinition
import com.jarvis.assistant.services.AlarmReceiver
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.putJsonObject
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tool for device-level functions: alarms, reminders, calendar events.
 */
@Singleton
class DeviceTool @Inject constructor(
    @ApplicationContext private val context: Context
) : Tool {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    override fun getName(): String = "device_control"

    override fun getDescription(): String = "Set alarms, reminders, and calendar events"

    override fun getDefinition(): ToolDefinition = ToolDefinition(
        name = getName(),
        description = getDescription(),
        parameters = buildJsonObject {
            putJsonObject("properties") {
                putJsonObject("action") {
                    put("type", "string")
                    put("description", "Action type: set_alarm, set_reminder")
                }
                putJsonObject("time") {
                    put("type", "string")
                    put("description", "Time in format HH:MM or natural language like '7 AM'")
                }
                putJsonObject("label") {
                    put("type", "string")
                    put("description", "Label or description for the alarm/reminder")
                }
            }
        }
    )

    override suspend fun execute(input: String): String {
        val lower = input.lowercase()

        return when {
            lower.contains("alarm") || lower.contains("wake me") -> {
                val time = extractTime(lower)
                val label = extractLabel(input, "alarm")
                setAlarm(time, label)
            }
            lower.contains("remind") -> {
                val reminderText = extractReminderText(input)
                val time = extractTime(lower)
                setReminder(reminderText, time)
            }
            else -> "Unknown device control command"
        }
    }

    override suspend fun executeWithParams(params: Map<String, String>): String {
        val action = params["action"] ?: "set_alarm"
        val time = params["time"] ?: "08:00"
        val label = params["label"] ?: params["text"] ?: params["reminder"] ?: "Alarm"

        return when (action.lowercase()) {
            "set_alarm", "alarm" -> setAlarm(time, label)
            "set_reminder", "reminder" -> setReminder(label, time)
            else -> "Unknown action: $action"
        }
    }

    private fun setAlarm(timeStr: String, label: String): String {
        return try {
            val (hour, minute) = parseTime(timeStr)

            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "$hour:${String.format("%02d", minute)}"
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to set alarm", e)
            "Failed to set alarm: ${e.localizedMessage}"
        }
    }

    private fun setReminder(text: String, timeStr: String?): String {
        return try {
            val calendar = Calendar.getInstance()
            timeStr?.let {
                val (hour, minute) = parseTime(it)
                calendar.set(Calendar.HOUR_OF_DAY, hour)
                calendar.set(Calendar.MINUTE, minute)
            }

            val intent = Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, text)
                putExtra(CalendarContract.Events.DESCRIPTION, "Reminder set by JARVIS")
                putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, calendar.timeInMillis)
                putExtra(CalendarContract.EXTRA_EVENT_END_TIME, calendar.timeInMillis + 60 * 60 * 1000)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            text
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to set reminder", e)
            "Failed to set reminder: ${e.localizedMessage}"
        }
    }

    private fun parseTime(timeStr: String): Pair<Int, Int> {
        // Try parsing "7:30 AM" or "14:30" formats
        val cleaned = timeStr.trim().uppercase()

        // Pattern: HH:MM
        val timeRegex = Regex("(\\d{1,2}):?(\\d{2})?\\s*(AM|PM)?")
        val match = timeRegex.find(cleaned)

        if (match != null) {
            var hour = match.groupValues[1].toIntOrNull() ?: 8
            val minute = match.groupValues[2].toIntOrNull() ?: 0
            val ampm = match.groupValues[3]

            if (ampm == "PM" && hour < 12) hour += 12
            if (ampm == "AM" && hour == 12) hour = 0

            return Pair(hour.coerceIn(0, 23), minute.coerceIn(0, 59))
        }

        // Default fallback
        return Pair(8, 0)
    }

    private fun extractTime(input: String): String {
        val timeRegex = Regex("(\\d{1,2}):?(\\d{2})?\\s*(AM|PM|am|pm)?")
        return timeRegex.find(input)?.value ?: "08:00"
    }

    private fun extractLabel(input: String, defaultType: String): String {
        return when {
            input.contains("work") -> "Work"
            input.contains("gym") -> "Gym"
            input.contains("meeting") -> "Meeting"
            input.contains("class") -> "Class"
            input.contains("appointment") -> "Appointment"
            else -> "$defaultType alarm"
        }
    }

    private fun extractReminderText(input: String): String {
        val lower = input.lowercase()
        val prefixes = listOf(
            "remind me to ",
            "remind me ",
            "reminder to ",
            "reminder ",
            "set a reminder to ",
            "create a reminder to "
        )
        for (prefix in prefixes) {
            val idx = lower.indexOf(prefix)
            if (idx >= 0) {
                return input.substring(idx + prefix.length).trim()
            }
        }
        return input
    }

    companion object {
        private const val TAG = "DeviceTool"
    }
}
