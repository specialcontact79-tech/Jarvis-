package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.domain.model.AppSettings
import com.jarvis.assistant.domain.repository.SettingsRepositoryInterface
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Use case for managing application settings.
 */
@Singleton
class ManageSettingsUseCase @Inject constructor(
    private val settingsRepository: SettingsRepositoryInterface
) {

    fun getSettings(): Flow<AppSettings> = settingsRepository.getSettings()

    suspend fun updateAiProvider(provider: String) {
        settingsRepository.updateAiProvider(provider)
    }

    suspend fun updateAiModel(model: String) {
        settingsRepository.updateAiModel(model)
    }

    suspend fun updateThemeMode(mode: String) {
        settingsRepository.updateThemeMode(mode)
    }

    suspend fun updateWakeWordSettings(enabled: Boolean, sensitivity: String) {
        settingsRepository.updateWakeWordSettings(enabled, sensitivity)
    }

    suspend fun updateVoiceSettings(language: String, speed: Float, pitch: Float) {
        settingsRepository.updateVoiceSettings(language, speed, pitch)
    }

    suspend fun updateHandsFreeMode(enabled: Boolean) {
        settingsRepository.updateHandsFreeMode(enabled)
    }

    suspend fun updateAutoSaveMemories(enabled: Boolean) {
        settingsRepository.updateAutoSaveMemories(enabled)
    }

    suspend fun saveApiKey(provider: String, apiKey: String) {
        when (provider) {
            "gemini" -> settingsRepository.saveGeminiApiKey(apiKey)
            "openai" -> settingsRepository.saveOpenAiApiKey(apiKey)
        }
    }

    suspend fun resetToDefaults() {
        settingsRepository.resetToDefaults()
    }

    fun hasApiKey(): Boolean = settingsRepository.hasAnyApiKey()
}
