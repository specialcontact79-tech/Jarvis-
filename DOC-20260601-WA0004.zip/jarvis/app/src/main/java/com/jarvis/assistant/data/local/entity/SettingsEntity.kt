package com.jarvis.assistant.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.Instant

/**
 * Entity representing user settings stored in the local database.
 * API keys are NOT stored here - they use EncryptedSharedPreferences.
 */
@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: Int = 1, // Single row for app settings

    @ColumnInfo(name = "ai_provider")
    val aiProvider: String = "gemini", // "gemini" or "openai"

    @ColumnInfo(name = "ai_model")
    val aiModel: String = "gemini-pro",

    @ColumnInfo(name = "voice_language")
    val voiceLanguage: String = "en-US",

    @ColumnInfo(name = "voice_speed")
    val voiceSpeed: Float = 1.0f,

    @ColumnInfo(name = "voice_pitch")
    val voicePitch: Float = 1.0f,

    @ColumnInfo(name = "wake_word_enabled")
    val wakeWordEnabled: Boolean = false,

    @ColumnInfo(name = "wake_word_sensitivity")
    val wakeWordSensitivity: String = "medium", // "low", "medium", "high"

    @ColumnInfo(name = "theme_mode")
    val themeMode: String = "system", // "system", "light", "dark", "amoled"

    @ColumnInfo(name = "hands_free_mode")
    val handsFreeMode: Boolean = false,

    @ColumnInfo(name = "conversation_history_enabled")
    val conversationHistoryEnabled: Boolean = true,

    @ColumnInfo(name = "auto_save_memories")
    val autoSaveMemories: Boolean = true,

    @ColumnInfo(name = "last_updated")
    val lastUpdated: Instant = Instant.now()
)
