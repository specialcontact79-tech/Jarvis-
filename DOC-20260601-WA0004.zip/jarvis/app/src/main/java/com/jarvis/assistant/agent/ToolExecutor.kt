package com.jarvis.assistant.agent

import com.jarvis.assistant.tools.Tool
import com.jarvis.assistant.utils.Logger
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Executes tools with extracted parameters.
 */
@Singleton
class ToolExecutor @Inject constructor() {

    /**
     * Executes a tool by parsing parameters from natural language.
     */
    suspend fun execute(tool: Tool, userMessage: String): String {
        Logger.i(TAG, "Executing tool: ${tool.getName()}")
        return try {
            tool.execute(userMessage)
        } catch (e: Exception) {
            Logger.e(TAG, "Tool execution failed: ${tool.getName()}", e)
            "Failed to execute ${tool.getName()}: ${e.localizedMessage}"
        }
    }

    /**
     * Executes a tool with pre-extracted parameters.
     */
    suspend fun executeWithParams(tool: Tool, params: Map<String, String>): String {
        Logger.i(TAG, "Executing tool: ${tool.getName()} with params: $params")
        return try {
            tool.executeWithParams(params)
        } catch (e: Exception) {
            Logger.e(TAG, "Tool execution failed: ${tool.getName()}", e)
            "Failed to execute ${tool.getName()}: ${e.localizedMessage}"
        }
    }

    companion object {
        private const val TAG = "ToolExecutor"
    }
}
