package com.jarvis.assistant.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.domain.model.Memory
import com.jarvis.assistant.presentation.theme.*
import com.jarvis.assistant.presentation.viewmodel.MemoryViewModel
import com.jarvis.assistant.utils.toDateTimeString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoryScreen(
    viewModel: MemoryViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val allMemories by viewModel.allMemories.collectAsState()
    val shortTerm by viewModel.shortTermMemories.collectAsState()
    val longTerm by viewModel.longTermMemories.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("All", "Short-term", "Long-term")

    Scaffold(
        topBar = { TopAppBar(title = { Text("Memory") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }, containerColor = JarvisBlue) {
                Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier.fillMaxSize().padding(paddingValues)
        ) {
            TabRow(selectedTabIndex = selectedTab, containerColor = MaterialTheme.colorScheme.background) {
                tabs.forEachIndexed { index, title ->
                    Tab(selected = selectedTab == index, onClick = { selectedTab = index }, text = { Text(title) })
                }
            }
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it; if (it.isNotBlank()) viewModel.searchMemories(it) },
                placeholder = { Text("Search memories...") },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            val displayed = when (selectedTab) {
                0 -> if (searchQuery.isNotBlank()) uiState.searchResults else allMemories
                1 -> shortTerm
                else -> longTerm
            }
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (displayed.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp), contentAlignment = Alignment.Center) {
                            Text("No memories yet", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    items(displayed, key = { it.id }) { memory ->
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                            Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.Top) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(memory.content, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Badge(containerColor = if (memory.memoryType == "long_term") JarvisPurple.copy(alpha = 0.2f) else JarvisBlue.copy(alpha = 0.2f)) {
                                            Text(memory.memoryType.replace("_", " "), color = if (memory.memoryType == "long_term") JarvisPurple else JarvisBlue)
                                        }
                                        Text(memory.createdAt.toDateTimeString(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                IconButton(onClick = { viewModel.deleteMemory(memory.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = JarvisRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (showAddDialog) {
        var content by remember { mutableStateOf("") }
        var isLongTerm by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Memory") },
            text = {
                Column {
                    OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Memory content") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isLongTerm, onCheckedChange = { isLongTerm = it })
                        Text("Long-term memory")
                    }
                }
            },
            confirmButton = { Button(onClick = { if (content.isNotBlank()) { viewModel.addMemory(content, isLongTerm = isLongTerm); showAddDialog = false } }, enabled = content.isNotBlank()) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } }
        )
    }
}
