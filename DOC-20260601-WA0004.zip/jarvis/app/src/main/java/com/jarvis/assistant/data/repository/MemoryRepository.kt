package com.jarvis.assistant.data.repository

import com.jarvis.assistant.data.local.db.JarvisDatabase
import com.jarvis.assistant.data.local.entity.MemoryEntity
import com.jarvis.assistant.domain.model.Memory
import com.jarvis.assistant.domain.repository.MemoryRepositoryInterface
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.Instant
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for managing memories.
 */
@Singleton
class MemoryRepository @Inject constructor(
    private val db: JarvisDatabase,
    private val dispatcher: CoroutineDispatcher
) : MemoryRepositoryInterface {

    override fun getAllMemories(): Flow<List<Memory>> =
        db.memoryDao().getAllActiveMemories()
            .map { entities -> entities.map { it.toDomain() } }

    override fun getShortTermMemories(): Flow<List<Memory>> =
        db.memoryDao().getActiveShortTermMemories()
            .map { entities -> entities.map { it.toDomain() } }

    override fun getLongTermMemories(): Flow<List<Memory>> =
        db.memoryDao().getLongTermMemories()
            .map { entities -> entities.map { it.toDomain() } }

    override suspend fun getMemoryById(memoryId: String): Memory? =
        withContext(dispatcher) {
            db.memoryDao().getMemoryById(memoryId)?.toDomain()
        }

    override suspend fun searchMemories(query: String): List<Memory> =
        withContext(dispatcher) {
            db.memoryDao().searchMemoriesByTopic(query)
                .map { it.toDomain() }
        }

    override suspend fun addMemory(memory: Memory): String =
        withContext(dispatcher) {
            val id = memory.id.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
            val entity = MemoryEntity(
                id = id,
                content = memory.content,
                category = memory.category,
                memoryType = memory.memoryType,
                keyTopics = memory.keyTopics,
                sourceConversationId = memory.sourceConversationId,
                confidenceScore = memory.confidenceScore,
                accessCount = memory.accessCount,
                lastAccessedAt = memory.lastAccessedAt,
                createdAt = memory.createdAt,
                expiresAt = memory.expiresAt,
                isActive = memory.isActive
            )
            db.memoryDao().insertMemory(entity)
            id
        }

    override suspend fun addMemories(memories: List<Memory>) =
        withContext(dispatcher) {
            val entities = memories.map { memory ->
                MemoryEntity(
                    id = memory.id.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString(),
                    content = memory.content,
                    category = memory.category,
                    memoryType = memory.memoryType,
                    keyTopics = memory.keyTopics,
                    sourceConversationId = memory.sourceConversationId,
                    confidenceScore = memory.confidenceScore,
                    accessCount = memory.accessCount,
                    lastAccessedAt = memory.lastAccessedAt,
                    createdAt = memory.createdAt,
                    expiresAt = memory.expiresAt,
                    isActive = memory.isActive
                )
            }
            db.memoryDao().insertMemories(entities)
        }

    override suspend fun updateMemory(memory: Memory) =
        withContext(dispatcher) {
            val entity = MemoryEntity(
                id = memory.id,
                content = memory.content,
                category = memory.category,
                memoryType = memory.memoryType,
                keyTopics = memory.keyTopics,
                sourceConversationId = memory.sourceConversationId,
                confidenceScore = memory.confidenceScore,
                accessCount = memory.accessCount,
                lastAccessedAt = memory.lastAccessedAt,
                createdAt = memory.createdAt,
                expiresAt = memory.expiresAt,
                isActive = memory.isActive
            )
            db.memoryDao().updateMemory(entity)
        }

    override suspend fun deleteMemory(memoryId: String) =
        withContext(dispatcher) {
            db.memoryDao().deleteMemoryById(memoryId)
        }

    override suspend fun recordAccess(memoryId: String) =
        withContext(dispatcher) {
            db.memoryDao().incrementAccess(memoryId)
        }

    override suspend fun cleanupExpiredMemories() =
        withContext(dispatcher) {
            db.memoryDao().deleteExpiredMemories(Instant.now())
        }

    override suspend fun getMemoryCount(): Int =
        withContext(dispatcher) {
            db.memoryDao().getMemoryCount()
        }

    // ==================== MAPPERS ====================

    private fun MemoryEntity.toDomain() = Memory(
        id = id,
        content = content,
        category = category,
        memoryType = memoryType,
        keyTopics = keyTopics,
        sourceConversationId = sourceConversationId,
        confidenceScore = confidenceScore,
        accessCount = accessCount,
        lastAccessedAt = lastAccessedAt,
        createdAt = createdAt,
        expiresAt = expiresAt,
        isActive = isActive
    )
}
