package com.jarvis.assistant.data.model

import kotlinx.serialization.Serializable

/**
 * Shared data models used across the data layer.
 */
@Serializable
data class ApiResponse<T>(
    val success: Boolean,
    val data: T? = null,
    val error: String? = null
)

@Serializable
data class ToolCallPayload(
    val toolName: String,
    val parameters: Map<String, String>
)

@Serializable
data class ToolExecutionResponse(
    val toolName: String,
    val success: Boolean,
    val result: String,
    val executionTimeMs: Long
)
