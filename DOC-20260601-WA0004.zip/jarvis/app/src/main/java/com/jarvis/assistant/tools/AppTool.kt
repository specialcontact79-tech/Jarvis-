package com.jarvis.assistant.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.jarvis.assistant.ai.ToolDefinition
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.putJsonObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tool for opening apps, settings, and websites.
 */
@Singleton
class AppTool @Inject constructor(
    @ApplicationContext private val context: Context
) : Tool {

    override fun getName(): String = "open_app"

    override fun getDescription(): String = "Open apps, system settings, or websites on the device"

    override fun getDefinition(): ToolDefinition = ToolDefinition(
        name = getName(),
        description = getDescription(),
        parameters = buildJsonObject {
            putJsonObject("properties") {
                putJsonObject("type") {
                    put("type", "string")
                    put("description", "Type of target: app, settings, or website")
                    putJsonObject("enum") {
                        // Can't use put in array, using description instead
                    }
                }
                putJsonObject("target") {
                    put("type", "string")
                    put("description", "Name of app, settings page, or URL to open")
                }
            }
            putJsonObject("required") {
                // Mark type and target as required
            }
        }
    )

    override suspend fun execute(input: String): String {
        val lower = input.lowercase()

        return when {
            // Website
            lower.contains("website") || lower.contains("browser") ||
                    lower.contains(".com") || lower.contains(".org") || lower.contains(".net") -> {
                val url = extractUrl(input) ?: return "Could not find a URL to open"
                openWebsite(url)
            }
            // Settings
            lower.contains("settings") || lower.contains("setting") -> {
                val settingName = extractSettingName(input)
                openSettings(settingName)
            }
            // App
            else -> {
                val appName = extractAppName(input) ?: return "Could not identify the app to open"
                openApp(appName)
            }
        }
    }

    override suspend fun executeWithParams(params: Map<String, String>): String {
        val type = params["type"] ?: params["target_type"] ?: "app"
        val target = params["target"] ?: params["app_name"] ?: params["url"] ?: params["setting_name"]
        ?: return "No target specified"

        return when (type.lowercase()) {
            "website", "url", "browser" -> openWebsite(target)
            "settings", "setting" -> openSettings(target)
            else -> openApp(target)
        }
    }

    private fun openApp(appName: String): String {
        val packageName = APP_PACKAGE_MAP[appName.lowercase()]
            ?: findInstalledApp(appName)
            ?: return "App '$appName' not found on this device"

        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
                ?: return "Cannot launch $appName"
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            appName
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to open app: $packageName", e)
            "Failed to open $appName"
        }
    }

    private fun openSettings(settingName: String?): String {
        val intent = when (settingName?.lowercase()) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "display", "brightness", "screen" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound", "volume", "audio" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "storage" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
            "application", "apps" -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            "developer" -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "date", "time" -> Intent(Settings.ACTION_DATE_SETTINGS)
            "language" -> Intent(Settings.ACTION_LOCALE_SETTINGS)
            "notification" -> Intent(Settings.ACTION_NOTIFICATION_SETTINGS)
            "vpn" -> Intent(Settings.ACTION_VPN_SETTINGS)
            "wireless" -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return settingName ?: "Settings"
    }

    private fun openWebsite(url: String): String {
        val formattedUrl = when {
            url.startsWith("http://") || url.startsWith("https://") -> url
            else -> "https://$url"
        }

        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(formattedUrl))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            formattedUrl
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to open website: $formattedUrl", e)
            "Failed to open $formattedUrl"
        }
    }

    private fun extractUrl(input: String): String? {
        val urlRegex = Regex("(?:https?://)?(?:www\\.)?([a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(/[^\\s]*)?)")
        return urlRegex.find(input)?.value
    }

    private fun extractAppName(input: String): String? {
        val lower = input.lowercase()
        for ((name, _) in APP_PACKAGE_MAP) {
            if (lower.contains(name)) return name
        }
        // Extract after "open", "launch", "start"
        val prefixes = listOf("open ", "launch ", "start ")
        for (prefix in prefixes) {
            val idx = lower.indexOf(prefix)
            if (idx >= 0) {
                return lower.substring(idx + prefix.length).trim()
            }
        }
        return null
    }

    private fun extractSettingName(input: String): String? {
        val lower = input.lowercase()
        val settingsList = listOf(
            "wifi", "bluetooth", "display", "brightness", "sound", "volume",
            "battery", "storage", "location", "security", "apps", "developer",
            "accessibility", "date", "language", "notification", "vpn", "wireless"
        )
        for (setting in settingsList) {
            if (lower.contains(setting)) return setting
        }
        return null
    }

    private fun findInstalledApp(appName: String): String? {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(0)
        val lowerAppName = appName.lowercase()

        return apps.firstOrNull { app ->
            val label = pm.getApplicationLabel(app).toString().lowercase()
            label.contains(lowerAppName) || lowerAppName.contains(label)
        }?.packageName
    }

    companion object {
        private const val TAG = "AppTool"

        private val APP_PACKAGE_MAP = mapOf(
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "browser" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "email" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "photos" to "com.google.android.apps.photos",
            "google photos" to "com.google.android.apps.photos",
            "drive" to "com.google.android.apps.docs",
            "google drive" to "com.google.android.apps.docs",
            "calendar" to "com.google.android.calendar",
            "google calendar" to "com.google.android.calendar",
            "contacts" to "com.google.android.contacts",
            "phone" to "com.google.android.dialer",
            "messages" to "com.google.android.apps.messaging",
            "messaging" to "com.google.android.apps.messaging",
            "clock" to "com.google.android.deskclock",
            "calculator" to "com.google.android.calculator",
            "play store" to "com.android.vending",
            "google play" to "com.android.vending",
            "spotify" to "com.spotify.music",
            "netflix" to "com.netflix.mediaclient",
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "twitter" to "com.twitter.android",
            "telegram" to "org.telegram.messenger",
            "discord" to "com.discord",
            "camera" to "com.android.camera2",
            "settings" to "com.android.settings",
            "google" to "com.google.android.googlequicksearchbox"
        )
    }
}
