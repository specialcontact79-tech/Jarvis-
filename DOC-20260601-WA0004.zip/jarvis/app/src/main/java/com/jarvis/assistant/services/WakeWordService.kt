package com.jarvis.assistant.services

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.R
import com.jarvis.assistant.presentation.MainActivity
import com.jarvis.assistant.voice.WakeWordDetector
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Foreground service for wake word detection.
 *
 * Runs continuously in the background listening for "Hey JARVIS" activation phrase.
 */
@AndroidEntryPoint
class WakeWordService : Service() {

    @Inject
    lateinit var wakeWordDetector: WakeWordDetector

    private val binder = WakeWordBinder()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * Binder for service communication.
     */
    inner class WakeWordBinder : Binder() {
        fun getService(): WakeWordService = this@WakeWordService
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
        startWakeWordDetection()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (!wakeWordDetector.isActive()) {
                    startWakeWordDetection()
                }
            }
            ACTION_STOP -> {
                wakeWordDetector.stopDetection()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeWordDetector.stopDetection()
        serviceScope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun startWakeWordDetection() {
        wakeWordDetector.startDetection()

        serviceScope.launch {
            wakeWordDetector.detectionState.collectLatest { state ->
                when (state) {
                    is WakeWordDetector.DetectionState.Detected -> {
                        showWakeupNotification()
                        // Launch main activity
                        launchMainActivity()
                        // Reset detector
                        wakeWordDetector.reset()
                    }
                    is WakeWordDetector.DetectionState.Error -> {
                        // Error handling - restart detection
                        wakeWordDetector.stopDetection()
                        kotlinx.coroutines.delay(1000)
                        wakeWordDetector.startDetection()
                    }
                    else -> { /* No action needed */ }
                }
            }
        }
    }

    private fun showWakeupNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, JarvisApplication.CHANNEL_ALERTS)
            .setContentTitle(getString(R.string.notification_wakeup_title))
            .setContentText(getString(R.string.notification_wakeup_text))
            .setSmallIcon(R.drawable.ic_voice)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(WAKEUP_NOTIFICATION_ID, notification)
    }

    private fun launchMainActivity() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_WAKE_WORD_DETECTED, true)
        }
        startActivity(intent)
    }

    private fun buildNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, JarvisApplication.CHANNEL_VOICE_ASSISTANT)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.wake_word_listening))
            .setSmallIcon(R.drawable.ic_microphone)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    companion object {
        const val ACTION_START = "com.jarvis.assistant.action.START_WAKE_WORD"
        const val ACTION_STOP = "com.jarvis.assistant.action.STOP_WAKE_WORD"
        const val NOTIFICATION_ID = JarvisApplication.NOTIFICATION_ID_WAKE_WORD
        const val WAKEUP_NOTIFICATION_ID = 2001
        const val EXTRA_WAKE_WORD_DETECTED = "wake_word_detected"

        fun startIntent(context: Context): Intent =
            Intent(context, WakeWordService::class.java).apply {
                action = ACTION_START
            }

        fun stopIntent(context: Context): Intent =
            Intent(context, WakeWordService::class.java).apply {
                action = ACTION_STOP
            }
    }
}
