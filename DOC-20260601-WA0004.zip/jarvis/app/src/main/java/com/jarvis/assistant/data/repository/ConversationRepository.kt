package com.jarvis.assistant.data.repository

import com.jarvis.assistant.data.local.db.JarvisDatabase
import com.jarvis.assistant.data.local.entity.ConversationEntity
import com.jarvis.assistant.data.local.entity.MessageEntity
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.model.Conversation
import com.jarvis.assistant.domain.repository.ConversationRepositoryInterface
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.Instant
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for managing conversations and messages.
 */
@Singleton
class ConversationRepository @Inject constructor(
    private val db: JarvisDatabase,
    private val dispatcher: CoroutineDispatcher
) : ConversationRepositoryInterface {

    // ==================== CONVERSATIONS ====================

    override fun getAllConversations(): Flow<List<Conversation>> =
        db.conversationDao().getActiveConversations()
            .map { entities -> entities.map { it.toDomain() } }

    override suspend fun getConversationById(conversationId: String): Conversation? =
        withContext(dispatcher) {
            db.conversationDao().getConversationById(conversationId)?.toDomain()
        }

    override suspend fun createConversation(title: String): Conversation =
        withContext(dispatcher) {
            val now = Instant.now()
            val conversation = ConversationEntity(
                id = UUID.randomUUID().toString(),
                title = title,
                createdAt = now,
                updatedAt = now,
                isActive = true,
                messageCount = 0
            )
            db.conversationDao().insertConversation(conversation)
            conversation.toDomain()
        }

    override suspend fun updateConversationTitle(conversationId: String, title: String) =
        withContext(dispatcher) {
            db.conversationDao().updateConversationTitle(conversationId, title, Instant.now())
        }

    override suspend fun archiveConversation(conversationId: String) =
        withContext(dispatcher) {
            db.conversationDao().archiveConversation(conversationId)
        }

    override suspend fun deleteConversation(conversationId: String) =
        withContext(dispatcher) {
            val entity = db.conversationDao().getConversationById(conversationId) ?: return@withContext
            db.conversationDao().deleteConversationWithMessages(entity)
        }

    // ==================== MESSAGES ====================

    override fun getMessagesForConversation(conversationId: String): Flow<List<ChatMessage>> =
        db.conversationDao().getMessagesForConversation(conversationId)
            .map { entities -> entities.map { it.toDomain() } }

    override suspend fun getRecentMessages(conversationId: String, limit: Int): List<ChatMessage> =
        withContext(dispatcher) {
            db.conversationDao().getRecentMessages(conversationId, limit)
                .map { it.toDomain() }
        }

    override suspend fun addMessage(conversationId: String, message: ChatMessage) =
        withContext(dispatcher) {
            val now = Instant.now()
            val entity = MessageEntity(
                id = message.id,
                conversationId = conversationId,
                content = message.content,
                role = message.role,
                timestamp = message.timestamp,
                toolCallsJson = message.toolCallsJson,
                toolResultsJson = message.toolResultsJson,
                isError = message.isError,
                processingTimeMs = message.processingTimeMs
            )
            db.conversationDao().insertMessageAndUpdateConversation(entity, conversationId, now)
        }

    override suspend fun addMessages(conversationId: String, messages: List<ChatMessage>) =
        withContext(dispatcher) {
            val now = Instant.now()
            val entities = messages.map { message ->
                MessageEntity(
                    id = message.id,
                    conversationId = conversationId,
                    content = message.content,
                    role = message.role,
                    timestamp = message.timestamp,
                    toolCallsJson = message.toolCallsJson,
                    toolResultsJson = message.toolResultsJson,
                    isError = message.isError,
                    processingTimeMs = message.processingTimeMs
                )
            }
            db.conversationDao().insertMessages(entities)
            db.conversationDao().incrementMessageCount(conversationId, now)
        }

    // ==================== MAPPERS ====================

    private fun ConversationEntity.toDomain() = Conversation(
        id = id,
        title = title,
        createdAt = createdAt,
        updatedAt = updatedAt,
        isActive = isActive,
        messageCount = messageCount,
        contextSummary = contextSummary
    )

    private fun MessageEntity.toDomain() = ChatMessage(
        id = id,
        conversationId = conversationId,
        content = content,
        role = role,
        timestamp = timestamp,
        toolCallsJson = toolCallsJson,
        toolResultsJson = toolResultsJson,
        isError = isError,
        processingTimeMs = processingTimeMs
    )
}
