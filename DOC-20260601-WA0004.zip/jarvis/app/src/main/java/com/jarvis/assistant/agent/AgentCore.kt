package com.jarvis.assistant.agent

import com.jarvis.assistant.ai.AiEngine
import com.jarvis.assistant.ai.AiResponse
import com.jarvis.assistant.ai.ToolCall
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.model.Memory
import com.jarvis.assistant.tools.ToolRegistry
import com.jarvis.assistant.utils.Logger
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Core agent that orchestrates the AI processing pipeline.
 *
 * Agent flow:
 * User Command → Intent Analysis → Tool Selection → Tool Execution → Result Processing → Voice Response
 */
@Singleton
class AgentCore @Inject constructor(
    private val aiEngine: AiEngine,
    private val intentAnalyzer: IntentAnalyzer,
    private val toolSelector: ToolSelector,
    private val toolExecutor: ToolExecutor,
    private val responseGenerator: ResponseGenerator,
    private val toolRegistry: ToolRegistry
) {

    init {
        // Register all available tools with the AI engine
        toolRegistry.getAllTools().forEach { tool ->
            aiEngine.registerTool(tool.getDefinition())
        }
    }

    /**
     * Processes a user message through the agent pipeline.
     *
     * @param userMessage The raw user input
     * @param conversationHistory Previous messages for context
     * @param systemContext System-level context
     * @return AgentResult containing response and extracted memories
     */
    suspend fun process(
        userMessage: String,
        conversationHistory: List<ChatMessage>,
        systemContext: String
    ): AgentResult {
        Logger.i(TAG, "Processing message: $userMessage")

        val startTime = System.currentTimeMillis()

        // Step 1: Analyze intent
        val intent = intentAnalyzer.analyze(userMessage)
        Logger.i(TAG, "Detected intent: ${intent.type} (confidence: ${intent.confidence})")

        // Step 2: If direct tool intent with high confidence, execute directly
        if (intent.confidence > 0.8 && intent.type != "conversational") {
            val directResult = handleDirectToolExecution(userMessage, intent)
            if (directResult != null) {
                return directResult
            }
        }

        // Step 3: Send to AI with tool calling
        val response = try {
            aiEngine.sendMessage(
                messages = conversationHistory + ChatMessage.user(userMessage),
                systemPrompt = systemContext
            ).first()
        } catch (e: Exception) {
            Logger.e(TAG, "AI request failed", e)
            return AgentResult(
                response = "I'm sorry, I'm having trouble connecting to my AI services right now. Please check your internet connection and API key settings.",
                toolCalls = emptyList(),
                extractedMemories = emptyList()
            )
        }

        // Step 4: Handle tool calls from AI
        val toolResults = when (response) {
            is AiResponse.ToolCallResponse -> {
                Logger.i(TAG, "AI requested ${response.toolCalls.size} tool calls")
                executeToolCalls(response.toolCalls)
            }
            is AiResponse.Complete -> {
                // Normal text response
                return AgentResult(
                    response = response.text,
                    toolCalls = emptyList(),
                    extractedMemories = extractMemories(userMessage, response.text)
                )
            }
            is AiResponse.Error -> {
                return AgentResult(
                    response = "I encountered an error: ${response.message}",
                    toolCalls = emptyList(),
                    extractedMemories = emptyList(),
                    isError = true
                )
            }
            is AiResponse.Chunk -> {
                // Chunks are handled in streaming - should not reach here for non-streaming
                return AgentResult(
                    response = response.text,
                    toolCalls = emptyList(),
                    extractedMemories = emptyList()
                )
            }
        }

        // Step 5: Generate final response with tool results
        val finalResponse = if (toolResults.isNotEmpty()) {
            generateToolResponse(userMessage, conversationHistory, systemContext, toolResults)
        } else {
            "I've completed the requested actions."
        }

        val processingTime = System.currentTimeMillis() - startTime
        Logger.i(TAG, "Processing completed in ${processingTime}ms")

        return AgentResult(
            response = finalResponse,
            toolCalls = toolResults.map { it.name },
            extractedMemories = extractMemories(userMessage, finalResponse)
        )
    }

    private suspend fun handleDirectToolExecution(
        userMessage: String,
        intent: IntentAnalyzer.Intent
    ): AgentResult? {
        val tool = toolSelector.selectTool(intent)
        return if (tool != null) {
            Logger.i(TAG, "Direct tool execution: ${tool.getName()}")
            val result = toolExecutor.execute(tool, userMessage)
            AgentResult(
                response = result,
                toolCalls = listOf(tool.getName()),
                extractedMemories = emptyList()
            )
        } else null
    }

    private suspend fun executeToolCalls(toolCalls: List<ToolCall>): List<ToolExecutionResult> {
        return toolCalls.mapNotNull { toolCall ->
            try {
                val tool = toolRegistry.findTool(toolCall.name)
                if (tool != null) {
                    val result = toolExecutor.executeWithParams(tool, toolCall.arguments)
                    ToolExecutionResult(
                        name = toolCall.name,
                        success = true,
                        result = result
                    )
                } else {
                    ToolExecutionResult(
                        name = toolCall.name,
                        success = false,
                        result = "Tool not found: ${toolCall.name}"
                    )
                }
            } catch (e: Exception) {
                Logger.e(TAG, "Tool execution failed: ${toolCall.name}", e)
                ToolExecutionResult(
                    name = toolCall.name,
                    success = false,
                    result = "Error: ${e.localizedMessage}"
                )
            }
        }
    }

    private suspend fun generateToolResponse(
        userMessage: String,
        history: List<ChatMessage>,
        systemContext: String,
        toolResults: List<ToolExecutionResult>
    ): String {
        val toolResultSummary = toolResults.joinToString("\n") { result ->
            "${result.name}: ${if (result.success) "Success" else "Failed"} - ${result.result}"
        }

        val context = "The following tools were executed:\n$toolResultSummary\n\n" +
                "Summarize the results for the user in a natural, conversational way."

        val response = aiEngine.sendMessage(
            messages = listOf(
                ChatMessage.user(userMessage),
                ChatMessage.assistant("I executed some tools. Here's what happened:\n$toolResultSummary"),
                ChatMessage.user("Summarize what you did for me.")
            ),
            systemPrompt = systemContext + "\n\n" + context
        ).first()

        return when (response) {
            is AiResponse.Complete -> response.text
            is AiResponse.Chunk -> response.text
            else -> "I've completed the requested actions."
        }
    }

    private fun extractMemories(userMessage: String, assistantResponse: String): List<Memory> {
        // Simple memory extraction - can be enhanced with NLP
        val memories = mutableListOf<Memory>()

        // Extract user preferences from messages containing preferences
        val preferencePatterns = listOf(
            "my name is",
            "i prefer",
            "i like",
            "i don't like",
            "i want",
            "i need",
            "i am",
            "i'm",
            "i live in",
            "i work at"
        )

        val lowerMessage = userMessage.lowercase()
        for (pattern in preferencePatterns) {
            if (lowerMessage.contains(pattern)) {
                // Extract the statement after the pattern
                val index = lowerMessage.indexOf(pattern)
                val statement = userMessage.substring(index).trim()
                    .take(200) // Limit length

                if (statement.length > pattern.length + 2) {
                    memories.add(
                        Memory.longTerm(
                            content = "User said: $statement",
                            category = "user_preference",
                            keyTopics = extractTopics(statement)
                        )
                    )
                }
                break
            }
        }

        return memories
    }

    private fun extractTopics(text: String): List<String> {
        // Simple topic extraction
        val words = text.lowercase()
            .replace(Regex("[^a-z0-9\\s]"), "")
            .split(Regex("\\s+"))
            .filter { it.length > 3 }
            .distinct()
            .take(5)
        return words
    }

    data class AgentResult(
        val response: String,
        val toolCalls: List<String>,
        val extractedMemories: List<Memory>,
        val isError: Boolean = false
    )

    data class ToolExecutionResult(
        val name: String,
        val success: Boolean,
        val result: String
    )

    companion object {
        private const val TAG = "AgentCore"
    }
}
