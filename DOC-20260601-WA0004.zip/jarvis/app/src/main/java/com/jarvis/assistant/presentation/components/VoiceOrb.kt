package com.jarvis.assistant.presentation.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.R
import com.jarvis.assistant.presentation.theme.JarvisBlue
import com.jarvis.assistant.presentation.theme.JarvisPurple

/**
 * Animated voice orb component for voice interaction screen.
 */
@Composable
fun VoiceOrb(
    isListening: Boolean,
    isProcessing: Boolean,
    isSpeaking: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_orb")

    // Animation scales based on state
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = when {
            isListening -> 1.2f
            isProcessing -> 1.1f
            isSpeaking -> 1.15f
            else -> 1.05f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val outerScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = when {
            isListening -> 1.5f
            isProcessing -> 1.3f
            isSpeaking -> 1.4f
            else -> 1.2f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "outer_scale"
    )

    val orbColor = when {
        isListening -> JarvisBlue
        isProcessing -> JarvisPurple
        isSpeaking -> JarvisBlue.copy(green = 0.9f)
        else -> JarvisBlue.copy(alpha = 0.6f)
    }

    Box(
        modifier = modifier
            .size(200.dp)
            .scale(outerScale),
        contentAlignment = Alignment.Center
    ) {
        // Outer glow ring
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            orbColor.copy(alpha = 0.2f),
                            orbColor.copy(alpha = 0.05f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )

        // Middle ring
        Box(
            modifier = Modifier
                .size(160.dp)
                .scale(scale)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            orbColor.copy(alpha = 0.4f),
                            orbColor.copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )

        // Inner orb
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(100.dp)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(JarvisBlue, JarvisPurple)
                    ),
                    shape = CircleShape
                )
        ) {
            Icon(
                painter = painterResource(
                    id = when {
                        isListening -> R.drawable.ic_microphone
                        isProcessing -> R.drawable.ic_memory
                        else -> R.drawable.ic_voice
                    }
                ),
                contentDescription = if (isListening) "Listening" else "Voice",
                tint = Color.White,
                modifier = Modifier.size(40.dp)
            )
        }
    }
}
