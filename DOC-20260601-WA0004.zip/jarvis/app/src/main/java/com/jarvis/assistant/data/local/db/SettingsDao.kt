package com.jarvis.assistant.data.local.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.jarvis.assistant.data.local.entity.SettingsEntity
import kotlinx.coroutines.flow.Flow
import java.time.Instant

/**
 * Data Access Object for user settings.
 */
@Dao
interface SettingsDao {

    @Query("SELECT * FROM settings WHERE id = 1")
    fun getSettings(): Flow<SettingsEntity?>

    @Query("SELECT * FROM settings WHERE id = 1")
    suspend fun getSettingsSync(): SettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettings(settings: SettingsEntity)

    @Update
    suspend fun updateSettings(settings: SettingsEntity)

    @Query("UPDATE settings SET ai_provider = :provider, last_updated = :timestamp WHERE id = 1")
    suspend fun updateAiProvider(provider: String, timestamp: Instant = Instant.now())

    @Query("UPDATE settings SET ai_model = :model, last_updated = :timestamp WHERE id = 1")
    suspend fun updateAiModel(model: String, timestamp: Instant = Instant.now())

    @Query("UPDATE settings SET theme_mode = :themeMode, last_updated = :timestamp WHERE id = 1")
    suspend fun updateThemeMode(themeMode: String, timestamp: Instant = Instant.now())

    @Query("UPDATE settings SET wake_word_enabled = :enabled, last_updated = :timestamp WHERE id = 1")
    suspend fun updateWakeWordEnabled(enabled: Boolean, timestamp: Instant = Instant.now())

    @Query("UPDATE settings SET wake_word_sensitivity = :sensitivity, last_updated = :timestamp WHERE id = 1")
    suspend fun updateWakeWordSensitivity(sensitivity: String, timestamp: Instant = Instant.now())

    @Query("UPDATE settings SET voice_language = :language, voice_speed = :speed, voice_pitch = :pitch, last_updated = :timestamp WHERE id = 1")
    suspend fun updateVoiceSettings(
        language: String,
        speed: Float,
        pitch: Float,
        timestamp: Instant = Instant.now()
    )

    @Query("UPDATE settings SET hands_free_mode = :enabled, last_updated = :timestamp WHERE id = 1")
    suspend fun updateHandsFreeMode(enabled: Boolean, timestamp: Instant = Instant.now())

    @Query("UPDATE settings SET auto_save_memories = :enabled, last_updated = :timestamp WHERE id = 1")
    suspend fun updateAutoSaveMemories(enabled: Boolean, timestamp: Instant = Instant.now())

    @Query("UPDATE settings SET conversation_history_enabled = :enabled, last_updated = :timestamp WHERE id = 1")
    suspend fun updateConversationHistoryEnabled(enabled: Boolean, timestamp: Instant = Instant.now())

    @Query("UPDATE settings SET last_updated = :timestamp WHERE id = 1")
    suspend fun touchSettings(timestamp: Instant = Instant.now())
}
