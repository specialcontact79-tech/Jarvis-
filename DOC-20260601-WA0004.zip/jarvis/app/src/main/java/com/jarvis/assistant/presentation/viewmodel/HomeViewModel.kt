package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.domain.model.Conversation
import com.jarvis.assistant.domain.usecase.ManageMemoryUseCase
import com.jarvis.assistant.domain.usecase.ManageSettingsUseCase
import com.jarvis.assistant.domain.usecase.SendMessageUseCase
import com.jarvis.assistant.domain.repository.ConversationRepositoryInterface
import com.jarvis.assistant.presentation.components.JarvisStatus
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalTime
import javax.inject.Inject

/**
 * ViewModel for the Home screen.
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val conversationRepository: ConversationRepositoryInterface,
    private val sendMessageUseCase: SendMessageUseCase,
    private val manageMemoryUseCase: ManageMemoryUseCase,
    private val manageSettingsUseCase: ManageSettingsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val recentConversations: StateFlow<List<Conversation>> =
        conversationRepository.getAllConversations()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val hasApiKey: StateFlow<Boolean> = flow {
        emit(manageSettingsUseCase.hasApiKey())
    }.stateIn(viewModelScope, SharingStarted.Lazily, false)

    init {
        loadGreeting()
    }

    private fun loadGreeting() {
        val hour = LocalTime.now().hour
        val greeting = when (hour) {
            in 5..11 -> "Good morning"
            in 12..17 -> "Good afternoon"
            in 18..21 -> "Good evening"
            else -> "Good night"
        }
        _uiState.update { it.copy(greeting = greeting) }
    }

    fun createConversation(onCreated: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val conversation = conversationRepository.createConversation("New Conversation")
                onCreated(conversation.id)
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to create conversation", e)
            }
        }
    }

    fun quickCommand(command: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(status = JarvisStatus.Processing) }
            try {
                // Quick commands processed through AI
                _uiState.update { it.copy(
                    status = JarvisStatus.Idle,
                    lastResponse = "Command received: $command"
                ) }
            } catch (e: Exception) {
                _uiState.update { it.copy(status = JarvisStatus.Error) }
            }
        }
    }

    data class HomeUiState(
        val greeting: String = "Hello",
        val status: JarvisStatus = JarvisStatus.Idle,
        val lastResponse: String = "",
        val isLoading: Boolean = false
    )

    companion object {
        private const val TAG = "HomeViewModel"
    }
}
