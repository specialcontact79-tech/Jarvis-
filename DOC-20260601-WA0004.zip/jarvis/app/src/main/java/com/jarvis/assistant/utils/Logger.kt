package com.jarvis.assistant.utils

import android.util.Log
import com.jarvis.assistant.BuildConfig

/**
 * Application logger with debug/release awareness.
 */
object Logger {

    private const val DEFAULT_TAG = "JARVIS"

    @JvmStatic
    fun v(tag: String = DEFAULT_TAG, message: String) {
        if (BuildConfig.DEBUG) Log.v(tag, message)
    }

    @JvmStatic
    fun d(tag: String = DEFAULT_TAG, message: String) {
        if (BuildConfig.DEBUG) Log.d(tag, message)
    }

    @JvmStatic
    fun i(tag: String = DEFAULT_TAG, message: String) {
        Log.i(tag, message)
    }

    @JvmStatic
    fun w(tag: String = DEFAULT_TAG, message: String) {
        Log.w(tag, message)
    }

    @JvmStatic
    fun e(tag: String = DEFAULT_TAG, message: String, throwable: Throwable? = null) {
        if (throwable != null) {
            Log.e(tag, message, throwable)
        } else {
            Log.e(tag, message)
        }
    }
}
