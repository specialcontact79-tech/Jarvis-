package com.jarvis.assistant.services

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.R
import com.jarvis.assistant.presentation.MainActivity
import dagger.hilt.android.AndroidEntryPoint

/**
 * Foreground service for voice assistant functionality.
 *
 * Keeps the voice assistant running in the background for continuous listening.
 */
@AndroidEntryPoint
class VoiceAssistantService : Service() {

    private val binder = VoiceAssistantBinder()

    /**
     * Binder for service communication.
     */
    inner class VoiceAssistantBinder : Binder() {
        fun getService(): VoiceAssistantService = this@VoiceAssistantService
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, buildNotification())
            }
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun buildNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, JarvisApplication.CHANNEL_VOICE_ASSISTANT)
            .setContentTitle(getString(R.string.notification_listening_title))
            .setContentText(getString(R.string.notification_listening_text))
            .setSmallIcon(R.drawable.ic_microphone)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    companion object {
        const val ACTION_START = "com.jarvis.assistant.action.START_VOICE_ASSISTANT"
        const val ACTION_STOP = "com.jarvis.assistant.action.STOP_VOICE_ASSISTANT"
        const val NOTIFICATION_ID = JarvisApplication.NOTIFICATION_ID_VOICE_SERVICE

        /**
         * Creates start intent.
         */
        fun startIntent(context: android.content.Context): Intent =
            Intent(context, VoiceAssistantService::class.java).apply {
                action = ACTION_START
            }

        /**
         * Creates stop intent.
         */
        fun stopIntent(context: android.content.Context): Intent =
            Intent(context, VoiceAssistantService::class.java).apply {
                action = ACTION_STOP
            }
    }
}
