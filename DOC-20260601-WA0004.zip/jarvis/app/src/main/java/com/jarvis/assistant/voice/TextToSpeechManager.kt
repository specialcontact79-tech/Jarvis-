package com.jarvis.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jarvis.assistant.utils.Logger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages text-to-speech synthesis.
 *
 * Provides voice output with configurable language, speed, and pitch.
 */
@Singleton
class TextToSpeechManager @Inject constructor(
    private val context: Context
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var pendingMessage: String? = null

    private val _ttsState = MutableStateFlow<TtsState>(TtsState.Idle)
    val ttsState: StateFlow<TtsState> = _ttsState.asStateFlow()

    private var currentLanguage: Locale = Locale.US
    private var currentSpeed: Float = 1.0f
    private var currentPitch: Float = 1.0f

    /**
     * TTS states.
     */
    sealed class TtsState {
        data object Idle : TtsState()
        data object Speaking : TtsState()
        data object Completed : TtsState()
        data class Error(val message: String) : TtsState()
    }

    /**
     * Initializes the TTS engine.
     */
    fun initialize() {
        if (tts == null) {
            tts = TextToSpeech(context, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            configureTts()
            pendingMessage?.let {
                speak(it)
                pendingMessage = null
            }
            Logger.i(TAG, "TTS initialized successfully")
        } else {
            isInitialized = false
            _ttsState.value = TtsState.Error("Failed to initialize TTS")
            Logger.e(TAG, "TTS initialization failed")
        }
    }

    /**
     * Speaks the given text.
     */
    fun speak(text: String) {
        if (!isInitialized) {
            pendingMessage = text
            initialize()
            return
        }

        if (text.isBlank()) return

        // Stop any current speech
        stop()

        _ttsState.value = TtsState.Speaking

        val utteranceId = UUID.randomUUID().toString()

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } else {
            @Suppress("DEPRECATION")
            val params = HashMap<String, String>()
            params[TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID] = utteranceId
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params)
        }
    }

    /**
     * Stops current speech.
     */
    fun stop() {
        tts?.stop()
        _ttsState.value = TtsState.Idle
    }

    /**
     * Sets the speech language.
     */
    fun setLanguage(language: String) {
        currentLanguage = Locale.forLanguageTag(language)
        configureTts()
    }

    /**
     * Sets speech rate (speed).
     */
    fun setSpeechRate(rate: Float) {
        currentSpeed = rate.coerceIn(0.25f, 3.0f)
        configureTts()
    }

    /**
     * Sets speech pitch.
     */
    fun setPitch(pitch: Float) {
        currentPitch = pitch.coerceIn(0.5f, 2.0f)
        configureTts()
    }

    /**
     * Checks if TTS is speaking.
     */
    fun isSpeaking(): Boolean {
        return tts?.isSpeaking == true
    }

    /**
     * Checks if TTS is available.
     */
    fun isAvailable(): Boolean = isInitialized

    /**
     * Shuts down TTS engine.
     */
    fun shutdown() {
        tts?.shutdown()
        tts = null
        isInitialized = false
    }

    private fun configureTts() {
        tts?.apply {
            language = currentLanguage
            setSpeechRate(currentSpeed)
            setPitch(currentPitch)

            setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _ttsState.value = TtsState.Speaking
                }

                override fun onDone(utteranceId: String?) {
                    _ttsState.value = TtsState.Completed
                }

                override fun onError(utteranceId: String?) {
                    _ttsState.value = TtsState.Error("Speech synthesis error")
                }
            })
        }
    }

    companion object {
        private const val TAG = "TextToSpeechManager"
    }
}
