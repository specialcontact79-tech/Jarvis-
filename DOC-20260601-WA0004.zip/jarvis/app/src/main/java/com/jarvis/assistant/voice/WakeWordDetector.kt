package com.jarvis.assistant.voice

import android.content.Context
import com.jarvis.assistant.utils.Logger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Detects wake words for hands-free activation.
 *
 * Listens for "Hey JARVIS" or "JARVIS" to activate the assistant.
 */
@Singleton
class WakeWordDetector @Inject constructor(
    private val context: Context,
    private val speechRecognizerManager: SpeechRecognizerManager
) {

    private val _detectionState = MutableStateFlow<DetectionState>(DetectionState.Idle)
    val detectionState: StateFlow<DetectionState> = _detectionState.asStateFlow()

    private var detectionJob: Job? = null
    private var isListening = false

    // Wake word patterns
    private val wakeWords = listOf(
        "hey jarvis",
        "jarvis",
        "hi jarvis",
        "okay jarvis",
        "ok jarvis"
    )

    /**
     * Detection states.
     */
    sealed class DetectionState {
        data object Idle : DetectionState()
        data object Listening : DetectionState()
        data object Detected : DetectionState()
        data class Error(val message: String) : DetectionState()
    }

    /**
     * Starts wake word detection.
     */
    fun startDetection() {
        if (isListening) return
        isListening = true
        _detectionState.value = DetectionState.Listening

        detectionJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                while (isListening) {
                    try {
                        speechRecognizerManager.startListening().collect { result ->
                            when (result) {
                                is SpeechRecognizerManager.RecognitionResult.Success -> {
                                    checkWakeWord(result.text)
                                }
                                is SpeechRecognizerManager.RecognitionResult.Error -> {
                                    if (result.errorCode == android.speech.SpeechRecognizer.ERROR_NO_MATCH ||
                                        result.errorCode == android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                                    ) {
                                        // Expected errors, restart listening
                                        Logger.d(TAG, "Recognition timeout, restarting...")
                                    } else {
                                        Logger.e(TAG, "Recognition error: ${result.message}")
                                        _detectionState.value = DetectionState.Error(result.message)
                                    }
                                }
                            }
                        }
                    } catch (e: CancellationException) {
                        break
                    } catch (e: Exception) {
                        Logger.e(TAG, "Detection loop error", e)
                        delay(1000) // Wait before retry
                    }

                    // Small delay before restarting
                    if (isListening) {
                        delay(500)
                    }
                }
            } finally {
                isListening = false
                _detectionState.value = DetectionState.Idle
            }
        }
    }

    /**
     * Stops wake word detection.
     */
    fun stopDetection() {
        isListening = false
        detectionJob?.cancel()
        detectionJob = null
        speechRecognizerManager.stopListening()
        _detectionState.value = DetectionState.Idle
    }

    /**
     * Checks if the recognized text contains a wake word.
     */
    private fun checkWakeWord(text: String) {
        val lowerText = text.lowercase().trim()
        Logger.d(TAG, "Checking wake word in: $lowerText")

        for (wakeWord in wakeWords) {
            if (lowerText.contains(wakeWord)) {
                Logger.i(TAG, "Wake word detected: $wakeWord")
                _detectionState.value = DetectionState.Detected
                return
            }
        }
    }

    /**
     * Resets the detection state back to listening after handling a detection.
     */
    fun reset() {
        if (isListening) {
            _detectionState.value = DetectionState.Listening
        }
    }

    /**
     * Returns whether detection is currently active.
     */
    fun isActive(): Boolean = isListening

    companion object {
        private const val TAG = "WakeWordDetector"
    }
}
