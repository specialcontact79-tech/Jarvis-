package com.jarvis.assistant.data.local.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.jarvis.assistant.data.local.entity.MemoryEntity
import kotlinx.coroutines.flow.Flow
import java.time.Instant

/**
 * Data Access Object for memories.
 */
@Dao
interface MemoryDao {

    @Query("SELECT * FROM memories WHERE is_active = 1 ORDER BY created_at DESC")
    fun getAllActiveMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE is_active = 1 AND memory_type = :type ORDER BY created_at DESC")
    fun getMemoriesByType(type: String): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE is_active = 1 AND category = :category ORDER BY created_at DESC")
    fun getMemoriesByCategory(category: String): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE id = :memoryId")
    suspend fun getMemoryById(memoryId: String): MemoryEntity?

    @Query("SELECT * FROM memories WHERE is_active = 1 AND key_topics LIKE '%' || :topic || '%' ORDER BY access_count DESC")
    suspend fun searchMemoriesByTopic(topic: String): List<MemoryEntity>

    @Query("""
        SELECT * FROM memories 
        WHERE is_active = 1 
        AND memory_type = 'short_term' 
        AND (expires_at IS NULL OR expires_at > :now)
        ORDER BY last_accessed_at DESC NULLS LAST
    """)
    fun getActiveShortTermMemories(now: Instant = Instant.now()): Flow<List<MemoryEntity>>

    @Query("""
        SELECT * FROM memories 
        WHERE is_active = 1 
        AND memory_type = 'long_term'
        ORDER BY access_count DESC, created_at DESC
    """)
    fun getLongTermMemories(): Flow<List<MemoryEntity>>

    @Query("""
        SELECT * FROM memories 
        WHERE is_active = 1 
        AND memory_type = 'short_term'
        AND expires_at IS NOT NULL
        AND expires_at <= :now
    """)
    suspend fun getExpiredShortTermMemories(now: Instant = Instant.now()): List<MemoryEntity>

    @Query("""
        UPDATE memories 
        SET access_count = access_count + 1, last_accessed_at = :now
        WHERE id = :memoryId
    """)
    suspend fun incrementAccess(memoryId: String, now: Instant = Instant.now())

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemories(memories: List<MemoryEntity>)

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Delete
    suspend fun deleteMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :memoryId")
    suspend fun deleteMemoryById(memoryId: String)

    @Query("DELETE FROM memories WHERE is_active = 0")
    suspend fun purgeInactiveMemories()

    @Query("DELETE FROM memories WHERE memory_type = 'short_term' AND expires_at IS NOT NULL AND expires_at <= :now")
    suspend fun deleteExpiredMemories(now: Instant = Instant.now())

    @Query("SELECT COUNT(*) FROM memories WHERE is_active = 1")
    suspend fun getMemoryCount(): Int

    @Query("SELECT * FROM memories WHERE is_active = 1 AND source_conversation_id = :conversationId")
    suspend fun getMemoriesForConversation(conversationId: String): List<MemoryEntity>
}
