package com.jarvis.assistant.domain.repository

import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.model.Conversation
import kotlinx.coroutines.flow.Flow

/**
 * Interface for conversation repository operations.
 */
interface ConversationRepositoryInterface {

    fun getAllConversations(): Flow<List<Conversation>>

    suspend fun getConversationById(conversationId: String): Conversation?

    suspend fun createConversation(title: String): Conversation

    suspend fun updateConversationTitle(conversationId: String, title: String)

    suspend fun archiveConversation(conversationId: String)

    suspend fun deleteConversation(conversationId: String)

    fun getMessagesForConversation(conversationId: String): Flow<List<ChatMessage>>

    suspend fun getRecentMessages(conversationId: String, limit: Int): List<ChatMessage>

    suspend fun addMessage(conversationId: String, message: ChatMessage)

    suspend fun addMessages(conversationId: String, messages: List<ChatMessage>)
}
