package com.jarvis.assistant.presentation.navigation

/**
 * Navigation routes for JARVIS app.
 */
sealed class NavRoutes(val route: String) {

    data object Splash : NavRoutes("splash")
    data object Home : NavRoutes("home")
    data object Voice : NavRoutes("voice")
    data object Chat : NavRoutes("chat/{conversationId}") {
        fun createRoute(conversationId: String) = "chat/$conversationId"
    }
    data object Memory : NavRoutes("memory")
    data object Settings : NavRoutes("settings")
    data object Permissions : NavRoutes("permissions")

    companion object {
        val bottomNavItems = listOf(Home, Voice, Memory, Settings)
    }
}
