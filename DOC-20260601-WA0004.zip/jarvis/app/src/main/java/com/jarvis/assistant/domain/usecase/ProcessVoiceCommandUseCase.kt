package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.voice.TextToSpeechManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onEach
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Use case for processing voice commands.
 *
 * Converts speech to text, sends to AI, and speaks the response.
 */
@Singleton
class ProcessVoiceCommandUseCase @Inject constructor(
    private val sendMessageUseCase: SendMessageUseCase,
    private val ttsManager: TextToSpeechManager
) {

    /**
     * Processes a voice command and speaks the response.
     */
    operator fun invoke(
        conversationId: String,
        voiceCommand: String
    ): Flow<SendMessageUseCase.MessageResult> =
        sendMessageUseCase(conversationId, voiceCommand)
            .onEach { result ->
                if (result is SendMessageUseCase.MessageResult.Success) {
                    ttsManager.speak(result.message.content)
                }
            }
            .onCompletion { cause ->
                if (cause != null) {
                    val errorMsg = "I apologize, something went wrong processing your voice command."
                    ttsManager.speak(errorMsg)
                }
            }
}
