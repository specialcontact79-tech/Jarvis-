package com.jarvis.assistant.agent

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Generates natural language responses for tool execution results.
 */
@Singleton
class ResponseGenerator @Inject constructor() {

    /**
     * Generates a human-friendly response for a tool execution result.
     */
    fun generate(toolName: String, success: Boolean, result: String): String {
        return if (success) {
            when (toolName) {
                "open_app" -> "I've opened $result for you."
                "open_settings" -> "Opening $result settings."
                "open_website" -> "Opening $result in your browser."
                "flashlight" -> if (result == "on") "Flashlight is now on." else "Flashlight is now off."
                "bluetooth" -> if (result == "on") "Bluetooth is now enabled." else "Bluetooth is now disabled."
                "wifi" -> if (result == "on") "WiFi is now enabled." else "WiFi is now disabled."
                "volume" -> "Volume set to $result."
                "brightness" -> "Brightness set to $result%."
                "alarm" -> "Alarm set for $result."
                "reminder" -> "Reminder set: $result."
                "call" -> "Calling $result."
                "sms" -> "Message sent to $result."
                "camera" -> "Opening camera."
                "share" -> "Share dialog opened."
                else -> "Done. $result"
            }
        } else {
            "I had trouble with that. $result"
        }
    }

    /**
     * Generates an error response.
     */
    fun generateError(error: String): String {
        return "I apologize, but I encountered an issue: $error. Please try again or check your settings."
    }
}
