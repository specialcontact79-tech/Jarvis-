package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.repository.ConversationRepositoryInterface
import com.jarvis.assistant.domain.usecase.ProcessVoiceCommandUseCase
import com.jarvis.assistant.presentation.components.JarvisStatus
import com.jarvis.assistant.voice.SpeechRecognizerManager
import com.jarvis.assistant.voice.TextToSpeechManager
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Voice interaction screen.
 */
@HiltViewModel
class VoiceViewModel @Inject constructor(
    private val speechRecognizerManager: SpeechRecognizerManager,
    private val textToSpeechManager: TextToSpeechManager,
    private val processVoiceCommandUseCase: ProcessVoiceCommandUseCase,
    private val conversationRepository: ConversationRepositoryInterface
) : ViewModel() {

    private val _uiState = MutableStateFlow(VoiceUiState())
    val uiState: StateFlow<VoiceUiState> = _uiState.asStateFlow()

    val recognitionState = speechRecognizerManager.recognitionState
    val ttsState = textToSpeechManager.ttsState
    val transcription = speechRecognizerManager.transcription

    private var currentConversationId: String? = null

    fun startListening(conversationId: String) {
        currentConversationId = conversationId
        _uiState.update {
            it.copy(
                status = JarvisStatus.Listening,
                transcript = "",
                response = ""
            )
        }

        viewModelScope.launch {
            try {
                speechRecognizerManager.startListening().collect { result ->
                    when (result) {
                        is SpeechRecognizerManager.RecognitionResult.Success -> {
                            _uiState.update {
                                it.copy(
                                    transcript = result.text,
                                    status = if (result.isFinal) JarvisStatus.Processing else JarvisStatus.Listening
                                )
                            }
                            if (result.isFinal) {
                                processCommand(result.text, conversationId)
                            }
                        }
                        is SpeechRecognizerManager.RecognitionResult.Error -> {
                            _uiState.update {
                                it.copy(
                                    status = JarvisStatus.Error,
                                    errorMessage = result.message
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Logger.e(TAG, "Listening error", e)
                _uiState.update {
                    it.copy(status = JarvisStatus.Error, errorMessage = e.localizedMessage)
                }
            }
        }
    }

    fun stopListening() {
        speechRecognizerManager.stopListening()
        textToSpeechManager.stop()
        _uiState.update { it.copy(status = JarvisStatus.Idle) }
    }

    private fun processCommand(command: String, conversationId: String) {
        _uiState.update { it.copy(status = JarvisStatus.Processing) }

        viewModelScope.launch {
            processVoiceCommandUseCase(conversationId, command).collect { result ->
                when (result) {
                    is com.jarvis.assistant.domain.usecase.SendMessageUseCase.MessageResult.Loading -> {
                        _uiState.update { it.copy(status = JarvisStatus.Processing) }
                    }
                    is com.jarvis.assistant.domain.usecase.SendMessageUseCase.MessageResult.Success -> {
                        _uiState.update {
                            it.copy(
                                status = JarvisStatus.Speaking,
                                response = result.message.content,
                                toolCalls = result.toolCalls
                            )
                        }
                    }
                    is com.jarvis.assistant.domain.usecase.SendMessageUseCase.MessageResult.Error -> {
                        _uiState.update {
                            it.copy(
                                status = JarvisStatus.Error,
                                errorMessage = result.message
                            )
                        }
                    }
                }
            }
        }
    }

    fun createConversation(onCreated: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val conversation = conversationRepository.createConversation("Voice Conversation")
                onCreated(conversation.id)
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to create conversation", e)
            }
        }
    }

    data class VoiceUiState(
        val status: JarvisStatus = JarvisStatus.Idle,
        val transcript: String = "",
        val response: String = "",
        val toolCalls: List<String> = emptyList(),
        val errorMessage: String? = null
    )

    override fun onCleared() {
        super.onCleared()
        speechRecognizerManager.destroy()
    }

    companion object {
        private const val TAG = "VoiceViewModel"
    }
}
