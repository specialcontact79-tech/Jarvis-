package com.jarvis.assistant.domain.model

import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.UUID

/**
 * Domain model representing a stored memory.
 */
data class Memory(
    val id: String = UUID.randomUUID().toString(),
    val content: String,
    val category: String = "fact", // "user_preference", "fact", "context", "reminder"
    val memoryType: String = "short_term", // "short_term", "long_term"
    val keyTopics: List<String> = emptyList(),
    val sourceConversationId: String? = null,
    val confidenceScore: Float = 1.0f,
    val accessCount: Int = 0,
    val lastAccessedAt: Instant? = null,
    val createdAt: Instant = Instant.now(),
    val expiresAt: Instant? = null,
    val isActive: Boolean = true
) {
    /**
     * Creates a short-term memory with automatic expiration.
     */
    companion object {
        fun shortTerm(
            content: String,
            category: String = "context",
            keyTopics: List<String> = emptyList(),
            sourceConversationId: String? = null,
            expiresInHours: Long = 24
        ) = Memory(
            content = content,
            category = category,
            memoryType = "short_term",
            keyTopics = keyTopics,
            sourceConversationId = sourceConversationId,
            expiresAt = Instant.now().plus(expiresInHours, ChronoUnit.HOURS)
        )

        fun longTerm(
            content: String,
            category: String = "user_preference",
            keyTopics: List<String> = emptyList(),
            sourceConversationId: String? = null
        ) = Memory(
            content = content,
            category = category,
            memoryType = "long_term",
            keyTopics = keyTopics,
            sourceConversationId = sourceConversationId,
            expiresAt = null
        )
    }
}
