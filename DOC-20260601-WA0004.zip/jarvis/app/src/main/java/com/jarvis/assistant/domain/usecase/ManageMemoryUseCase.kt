package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.domain.model.Memory
import com.jarvis.assistant.domain.repository.MemoryRepositoryInterface
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Use case for managing memories.
 */
@Singleton
class ManageMemoryUseCase @Inject constructor(
    private val memoryRepository: MemoryRepositoryInterface
) {

    fun getAllMemories(): Flow<List<Memory>> = memoryRepository.getAllMemories()

    fun getShortTermMemories(): Flow<List<Memory>> = memoryRepository.getShortTermMemories()

    fun getLongTermMemories(): Flow<List<Memory>> = memoryRepository.getLongTermMemories()

    suspend fun addMemory(content: String, category: String = "fact", type: String = "short_term"): String {
        val memory = if (type == "long_term") {
            Memory.longTerm(content = content, category = category)
        } else {
            Memory.shortTerm(content = content, category = category)
        }
        return memoryRepository.addMemory(memory)
    }

    suspend fun addShortTermMemory(content: String, category: String = "context"): String {
        val memory = Memory.shortTerm(content = content, category = category)
        return memoryRepository.addMemory(memory)
    }

    suspend fun addLongTermMemory(content: String, category: String = "user_preference"): String {
        val memory = Memory.longTerm(content = content, category = category)
        return memoryRepository.addMemory(memory)
    }

    suspend fun deleteMemory(memoryId: String) {
        memoryRepository.deleteMemory(memoryId)
    }

    suspend fun cleanupExpiredMemories() {
        memoryRepository.cleanupExpiredMemories()
    }

    suspend fun searchMemories(query: String): List<Memory> {
        return memoryRepository.searchMemories(query)
    }
}
