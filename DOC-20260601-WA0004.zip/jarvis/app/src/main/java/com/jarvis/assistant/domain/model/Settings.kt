package com.jarvis.assistant.domain.model

/**
 * Domain model representing application settings.
 */
data class AppSettings(
    val aiProvider: String = "gemini",
    val aiModel: String = "gemini-pro",
    val voiceLanguage: String = "en-US",
    val voiceSpeed: Float = 1.0f,
    val voicePitch: Float = 1.0f,
    val wakeWordEnabled: Boolean = false,
    val wakeWordSensitivity: String = "medium",
    val themeMode: String = "system",
    val handsFreeMode: Boolean = false,
    val conversationHistoryEnabled: Boolean = true,
    val autoSaveMemories: Boolean = true
)
