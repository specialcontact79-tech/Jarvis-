package com.jarvis.assistant.tools

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager
import com.jarvis.assistant.ai.ToolDefinition
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.putJsonObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tool for communication: phone calls and SMS messages.
 */
@Singleton
class CommunicationTool @Inject constructor(
    @ApplicationContext private val context: Context
) : Tool {

    override fun getName(): String = "communication"

    override fun getDescription(): String = "Make phone calls and send SMS messages to contacts"

    override fun getDefinition(): ToolDefinition = ToolDefinition(
        name = getName(),
        description = getDescription(),
        parameters = buildJsonObject {
            putJsonObject("properties") {
                putJsonObject("action") {
                    put("type", "string")
                    put("description", "Action: call or sms")
                }
                putJsonObject("contact") {
                    put("type", "string")
                    put("description", "Contact name or phone number")
                }
                putJsonObject("message") {
                    put("type", "string")
                    put("description", "Message text (for SMS only)")
                }
            }
        }
    )

    override suspend fun execute(input: String): String {
        val lower = input.lowercase()

        return when {
            lower.contains("call") || lower.contains("phone") || lower.contains("dial") -> {
                val contactName = extractContactName(input)
                makeCall(contactName)
            }
            lower.contains("text") || lower.contains("sms") || lower.contains("message") -> {
                val (contact, message) = extractSmsDetails(input)
                sendSms(contact, message)
            }
            else -> "Unknown communication command"
        }
    }

    override suspend fun executeWithParams(params: Map<String, String>): String {
        val action = params["action"] ?: "call"
        val contact = params["contact"] ?: params["phone"] ?: params["number"]
        ?: return "No contact specified"
        val message = params["message"] ?: params["text"] ?: ""

        return when (action.lowercase()) {
            "call", "phone", "dial" -> makeCall(contact)
            "sms", "text", "message" -> sendSms(contact, message)
            else -> "Unknown action: $action"
        }
    }

    private fun makeCall(contactName: String): String {
        return try {
            val phoneNumber = resolveContact(contactName) ?: contactName

            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$phoneNumber")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            contactName
        } catch (e: SecurityException) {
            Logger.e(TAG, "Call permission denied", e)
            "Phone call permission required. Please grant permission in settings."
        } catch (e: Exception) {
            Logger.e(TAG, "Call failed", e)
            "Failed to call $contactName: ${e.localizedMessage}"
        }
    }

    private fun sendSms(contact: String, message: String): String {
        return try {
            val phoneNumber = resolveContact(contact) ?: contact

            // Use SMS intent for better UX
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$phoneNumber")
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            contact
        } catch (e: Exception) {
            Logger.e(TAG, "SMS failed", e)
            "Failed to send SMS: ${e.localizedMessage}"
        }
    }

    /**
     * Resolves a contact name to a phone number.
     */
    private fun resolveContact(nameOrNumber: String): String? {
        // If it looks like a number, use it directly
        if (nameOrNumber.matches(Regex("^[+\\d\\s()-]+$"))) {
            return nameOrNumber.replace(Regex("[^+\\d]"), "")
        }

        // Search contacts
        return try {
            val cursor: Cursor? = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$nameOrNumber%"),
                null
            )

            cursor?.use {
                if (it.moveToFirst()) {
                    val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    it.getString(numberIndex)
                } else null
            }
        } catch (e: SecurityException) {
            Logger.e(TAG, "Contacts permission denied", e)
            null
        }
    }

    private fun extractContactName(input: String): String {
        val lower = input.lowercase()
        val prefixes = listOf(
            "call ", "phone ", "dial ", "call the ", "call my "
        )
        for (prefix in prefixes) {
            val idx = lower.indexOf(prefix)
            if (idx >= 0) {
                return input.substring(idx + prefix.length).trim()
            }
        }
        return input
    }

    private fun extractSmsDetails(input: String): Pair<String, String> {
        val lower = input.lowercase()

        // Try "text X saying Y" or "message X with Y"
        val patterns = listOf(
            Regex("(?:text|message|sms)\\s+(.+?)\\s+(?:saying|with|that|to say)\\s+(.+)", RegexOption.IGNORE_CASE),
            Regex("(?:send|text)\\s+(.+?)\\s+(?:a\\s+)?(?:message\\s+)?(?:to\\s+)?(.+)", RegexOption.IGNORE_CASE)
        )

        for (pattern in patterns) {
            val match = pattern.find(input)
            if (match != null) {
                val contact = match.groupValues[1].trim()
                val message = match.groupValues[2].trim()
                if (contact.isNotBlank() && message.isNotBlank()) {
                    return Pair(contact, message)
                }
            }
        }

        // Fallback: split by "to"
        val parts = input.split(Regex("\\s+to\\s+", RegexOption.IGNORE_CASE), limit = 2)
        if (parts.size == 2) {
            return Pair(parts[1].trim(), parts[0].trim())
        }

        return Pair(input, "")
    }

    companion object {
        private const val TAG = "CommunicationTool"
    }
}
