package com.jarvis.assistant.data.local.db

import androidx.room.TypeConverter
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Room type converters for complex data types.
 */
class DatabaseConverters {

    private val json = Json { ignoreUnknownKeys = true }

    // ==================== Instant Converters ====================

    @TypeConverter
    fun fromInstant(instant: Instant?): Long? = instant?.toEpochMilli()

    @TypeConverter
    fun toInstant(epochMilli: Long?): Instant? = epochMilli?.let {
        Instant.ofEpochMilli(it)
    }

    // ==================== LocalDateTime Converters ====================

    @TypeConverter
    fun fromLocalDateTime(dateTime: LocalDateTime?): Long? = dateTime?.let {
        it.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }

    @TypeConverter
    fun toLocalDateTime(epochMilli: Long?): LocalDateTime? = epochMilli?.let {
        LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneId.systemDefault())
    }

    // ==================== String List Converters ====================

    @TypeConverter
    fun fromStringList(list: List<String>?): String? = list?.let {
        json.encodeToString(it)
    }

    @TypeConverter
    fun toStringList(jsonString: String?): List<String>? = jsonString?.let {
        json.decodeFromString<List<String>>(it)
    }

    // ==================== Map Converters ====================

    @TypeConverter
    fun fromStringMap(map: Map<String, String>?): String? = map?.let {
        json.encodeToString(it)
    }

    @TypeConverter
    fun toStringMap(jsonString: String?): Map<String, String>? = jsonString?.let {
        json.decodeFromString<Map<String, String>>(it)
    }
}
