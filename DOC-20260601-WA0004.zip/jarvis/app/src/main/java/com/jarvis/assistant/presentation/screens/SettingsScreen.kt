package com.jarvis.assistant.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.domain.model.AppSettings
import com.jarvis.assistant.presentation.theme.*
import com.jarvis.assistant.presentation.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel
) {
    val settings by viewModel.settings.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    var showApiKeyDialog by remember { mutableStateOf(false) }
    var selectedProvider by remember { mutableStateOf("") }

    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }) }) { paddingValues ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // AI Provider Section
            item { SectionTitle("AI Provider") }
            item {
                Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Current Provider", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(settings.aiProvider.uppercase(), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                            Row {
                                TextButton(onClick = { viewModel.updateAiProvider("gemini") }) { Text("Gemini", color = if (settings.aiProvider == "gemini") JarvisBlue else MaterialTheme.colorScheme.onSurfaceVariant) }
                                TextButton(onClick = { viewModel.updateAiProvider("openai") }) { Text("OpenAI", color = if (settings.aiProvider == "openai") JarvisBlue else MaterialTheme.colorScheme.onSurfaceVariant) }
                            }
                        }
                    }
                }
            }

            // API Keys
            item { SectionTitle("API Keys") }
            item {
                Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column {
                        SettingItem(title = "Gemini API Key", subtitle = "Configure Google Gemini API key", onClick = { selectedProvider = "gemini"; showApiKeyDialog = true })
                        Divider(color = DividerDark)
                        SettingItem(title = "OpenAI API Key", subtitle = "Configure OpenAI API key", onClick = { selectedProvider = "openai"; showApiKeyDialog = true })
                    }
                }
            }

            // Voice Settings
            item { SectionTitle("Voice") }
            item {
                Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("Speech Speed: ${String.format("%.1f", settings.voiceSpeed)}x")
                        Slider(value = settings.voiceSpeed, onValueChange = { viewModel.updateVoiceSettings(settings.voiceLanguage, it, settings.voicePitch) }, valueRange = 0.5f..2.0f, colors = SliderDefaults.colors(thumbColor = JarvisBlue, activeTrackColor = JarvisBlue))
                        Text("Pitch: ${String.format("%.1f", settings.voicePitch)}")
                        Slider(value = settings.voicePitch, onValueChange = { viewModel.updateVoiceSettings(settings.voiceLanguage, settings.voiceSpeed, it) }, valueRange = 0.5f..2.0f, colors = SliderDefaults.colors(thumbColor = JarvisPurple, activeTrackColor = JarvisPurple))
                    }
                }
            }

            // Wake Word
            item { SectionTitle("Wake Word") }
            item {
                Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Enable Wake Word", style = MaterialTheme.typography.bodyMedium)
                                Text("Listen for 'Hey JARVIS'", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = settings.wakeWordEnabled, onCheckedChange = { viewModel.updateWakeWord(it, settings.wakeWordSensitivity) }, colors = SwitchDefaults.colors(checkedThumbColor = JarvisBlue, checkedTrackColor = JarvisBlue.copy(alpha = 0.5f)))
                        }
                        if (settings.wakeWordEnabled) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Sensitivity: ${settings.wakeWordSensitivity.replaceFirstChar { it.uppercase() }}")
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                listOf("low", "medium", "high").forEach { level ->
                                    FilterChip(selected = settings.wakeWordSensitivity == level, onClick = { viewModel.updateWakeWord(settings.wakeWordEnabled, level) }, label = { Text(level.replaceFirstChar { it.uppercase() }) })
                                }
                            }
                        }
                    }
                }
            }

            // Theme
            item { SectionTitle("Appearance") }
            item {
                Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column {
                        listOf("system" to "System Default", "light" to "Light", "dark" to "Dark", "amoled" to "AMOLED Dark").forEach { (mode, label) ->
                            Row(modifier = Modifier.fillMaxWidth().clickable { viewModel.updateThemeMode(mode) }.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(label, style = MaterialTheme.typography.bodyMedium)
                                if (settings.themeMode == mode) {
                                    Badge(containerColor = JarvisBlue.copy(alpha = 0.2f)) { Text("Active", color = JarvisBlue) }
                                }
                            }
                        }
                    }
                }
            }

            // Other Settings
            item { SectionTitle("General") }
            item {
                Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column {
                        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column { Text("Auto-save Memories", style = MaterialTheme.typography.bodyMedium); Text("Save context from conversations", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            Switch(checked = settings.autoSaveMemories, onCheckedChange = { viewModel.updateAutoSaveMemories(it) }, colors = SwitchDefaults.colors(checkedThumbColor = JarvisBlue))
                        }
                        Divider(color = DividerDark)
                        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column { Text("Hands-free Mode", style = MaterialTheme.typography.bodyMedium); Text("Continuous voice interaction", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            Switch(checked = settings.handsFreeMode, onCheckedChange = { viewModel.updateHandsFreeMode(it) }, colors = SwitchDefaults.colors(checkedThumbColor = JarvisBlue))
                        }
                    }
                }
            }

            // Reset
            item {
                OutlinedButton(onClick = { viewModel.resetToDefaults() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisRed)) {
                    Text("Reset All Settings")
                }
            }
        }
    }

    // API Key Dialog
    if (showApiKeyDialog) {
        var apiKey by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            title = { Text("${selectedProvider.uppercase()} API Key") },
            text = {
                Column {
                    Text("Enter your API key. It will be stored securely on your device.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
            },
            confirmButton = { Button(onClick = { if (apiKey.isNotBlank()) { viewModel.saveApiKey(selectedProvider, apiKey); showApiKeyDialog = false } }, enabled = apiKey.isNotBlank()) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showApiKeyDialog = false }) { Text("Cancel") } }
        )
    }

    // Success/error messages
    LaunchedEffect(uiState.successMessage) {
        if (uiState.successMessage != null) {
            viewModel.clearMessages()
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 8.dp))
}

@Composable
private fun SettingItem(title: String, subtitle: String, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
