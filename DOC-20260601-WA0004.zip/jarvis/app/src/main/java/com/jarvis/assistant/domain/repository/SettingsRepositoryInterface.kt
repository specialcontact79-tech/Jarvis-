package com.jarvis.assistant.domain.repository

import com.jarvis.assistant.domain.model.AiConfig
import com.jarvis.assistant.domain.model.AppSettings
import kotlinx.coroutines.flow.Flow

/**
 * Interface for settings repository operations.
 */
interface SettingsRepositoryInterface {

    fun getSettings(): Flow<AppSettings>

    suspend fun getSettingsSync(): AppSettings

    suspend fun updateAiProvider(provider: String)

    suspend fun updateAiModel(model: String)

    suspend fun updateThemeMode(mode: String)

    suspend fun updateWakeWordSettings(enabled: Boolean, sensitivity: String)

    suspend fun updateVoiceSettings(language: String, speed: Float, pitch: Float)

    suspend fun updateHandsFreeMode(enabled: Boolean)

    suspend fun updateAutoSaveMemories(enabled: Boolean)

    suspend fun saveGeminiApiKey(apiKey: String)

    suspend fun saveOpenAiApiKey(apiKey: String)

    fun getGeminiApiKey(): String?

    fun getOpenAiApiKey(): String?

    fun hasAnyApiKey(): Boolean

    suspend fun getAiConfig(): AiConfig

    suspend fun resetToDefaults()
}
