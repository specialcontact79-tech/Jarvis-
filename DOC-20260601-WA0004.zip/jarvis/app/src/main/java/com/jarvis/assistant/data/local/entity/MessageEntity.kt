package com.jarvis.assistant.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.Instant

/**
 * Entity representing a single message in a conversation.
 */
@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversation_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("conversation_id")]
)
data class MessageEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "conversation_id")
    val conversationId: String,

    @ColumnInfo(name = "content")
    val content: String,

    @ColumnInfo(name = "role")
    val role: String, // "user", "assistant", "system", "tool"

    @ColumnInfo(name = "timestamp")
    val timestamp: Instant,

    @ColumnInfo(name = "tool_calls")
    val toolCallsJson: String? = null,

    @ColumnInfo(name = "tool_results")
    val toolResultsJson: String? = null,

    @ColumnInfo(name = "is_error")
    val isError: Boolean = false,

    @ColumnInfo(name = "processing_time_ms")
    val processingTimeMs: Long? = null
)
