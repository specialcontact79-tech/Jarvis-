package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.ai.AiEngine
import com.jarvis.assistant.agent.AgentCore
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.model.Memory
import com.jarvis.assistant.domain.repository.ConversationRepositoryInterface
import com.jarvis.assistant.domain.repository.MemoryRepositoryInterface
import com.jarvis.assistant.utils.Logger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Use case for sending a message and getting AI response.
 *
 * Flow:
 * 1. Save user message to conversation
 * 2. Load conversation history as context
 * 3. Load relevant memories
 * 4. Send to AI engine with tool calling support
 * 5. Save AI response
 * 6. Extract and save new memories
 */
@Singleton
class SendMessageUseCase @Inject constructor(
    private val aiEngine: AiEngine,
    private val conversationRepository: ConversationRepositoryInterface,
    private val memoryRepository: MemoryRepositoryInterface,
    private val agentCore: AgentCore
) {

    /**
     * Sends a message and streams the AI response.
     */
    operator fun invoke(
        conversationId: String,
        message: String
    ): Flow<MessageResult> = flow {
        emit(MessageResult.Loading)

        try {
            // Save user message
            val userMessage = ChatMessage.user(message)
            conversationRepository.addMessage(conversationId, userMessage)

            // Get conversation history for context
            val history = conversationRepository.getRecentMessages(conversationId, limit = 20)

            // Get relevant memories
            val memories = memoryRepository.searchMemories(message)
                .take(5)

            // Build system prompt with context
            val systemPrompt = buildSystemPrompt(memories)

            // Process through agent for tool calling
            val agentResult = agentCore.process(
                userMessage = message,
                conversationHistory = history,
                systemContext = systemPrompt
            )

            // Save assistant response
            val assistantMessage = ChatMessage.assistant(agentResult.response)
            conversationRepository.addMessage(conversationId, assistantMessage)

            // Extract and save memories
            if (agentResult.extractedMemories.isNotEmpty()) {
                memoryRepository.addMemories(agentResult.extractedMemories)
            }

            emit(
                MessageResult.Success(
                    message = assistantMessage,
                    toolCalls = agentResult.toolCalls
                )
            )
        } catch (e: Exception) {
            Logger.e("SendMessageUseCase", "Error processing message", e)

            // Save error message
            val errorMessage = ChatMessage.assistant(
                content = "I apologize, but I encountered an error: ${e.localizedMessage}"
            ).copy(isError = true)
            conversationRepository.addMessage(conversationId, errorMessage)

            emit(MessageResult.Error(e.localizedMessage ?: "Unknown error"))
        }
    }

    private fun buildSystemPrompt(memories: List<Memory>): String {
        val memoryContext = if (memories.isNotEmpty()) {
            "\n\nRelevant context from memory:\n" +
                memories.joinToString("\n") { "- ${it.content}" }
        } else ""

        return "You are JARVIS, a helpful AI assistant. You can control the user's device, " +
                "open apps, manage settings, and help with daily tasks. " +
                "Be concise but helpful in your responses." +
                memoryContext
    }

    sealed class MessageResult {
        data object Loading : MessageResult()
        data class Success(val message: ChatMessage, val toolCalls: List<String>) : MessageResult()
        data class Error(val message: String) : MessageResult()
    }
}
