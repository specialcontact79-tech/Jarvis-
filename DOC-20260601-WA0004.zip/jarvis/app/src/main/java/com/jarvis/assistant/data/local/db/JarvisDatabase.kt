package com.jarvis.assistant.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.jarvis.assistant.data.local.entity.ConversationEntity
import com.jarvis.assistant.data.local.entity.MemoryEntity
import com.jarvis.assistant.data.local.entity.MessageEntity
import com.jarvis.assistant.data.local.entity.SettingsEntity

/**
 * Room database for JARVIS.
 *
 * Stores conversations, messages, memories, and user settings.
 * Version 1: Initial schema
 */
@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        MemoryEntity::class,
        SettingsEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(DatabaseConverters::class)
abstract class JarvisDatabase : RoomDatabase() {

    abstract fun conversationDao(): ConversationDao
    abstract fun memoryDao(): MemoryDao
    abstract fun settingsDao(): SettingsDao
}
