package com.jarvis.assistant.ai

import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.repository.SettingsRepositoryInterface
import com.jarvis.assistant.utils.Logger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import javax.inject.Inject
import javax.inject.Singleton

/**
 * AI Engine that manages and routes requests to the configured AI provider.
 *
 * This is the main entry point for AI operations in JARVIS.
 * It handles provider selection, tool registration, and response processing.
 */
@Singleton
class AiEngine @Inject constructor(
    private val geminiProvider: GeminiProvider,
    private val openAiProvider: OpenAiProvider,
    private val settingsRepository: SettingsRepositoryInterface
) {

    private val toolDefinitions = mutableListOf<ToolDefinition>()

    /**
     * Registers a tool definition for AI function calling.
     */
    fun registerTool(tool: ToolDefinition) {
        if (toolDefinitions.none { it.name == tool.name }) {
            toolDefinitions.add(tool)
            Logger.i(TAG, "Registered tool: ${tool.name}")
        }
    }

    /**
     * Registers multiple tool definitions.
     */
    fun registerTools(tools: List<ToolDefinition>) {
        tools.forEach { registerTool(it) }
    }

    /**
     * Unregisters a tool by name.
     */
    fun unregisterTool(toolName: String) {
        toolDefinitions.removeAll { it.name == toolName }
    }

    /**
     * Gets all registered tool definitions.
     */
    fun getRegisteredTools(): List<ToolDefinition> = toolDefinitions.toList()

    /**
     * Sends a message to the configured AI provider.
     */
    suspend fun sendMessage(
        messages: List<ChatMessage>,
        systemPrompt: String = ""
    ): Flow<AiResponse> {
        val provider = getActiveProvider()
        return provider.sendMessage(messages, systemPrompt, toolDefinitions)
    }

    /**
     * Quick send - simple message without history.
     */
    suspend fun quickSend(
        message: String,
        systemPrompt: String = ""
    ): Flow<AiResponse> {
        val chatMessage = ChatMessage.user(message)
        return sendMessage(listOf(chatMessage), systemPrompt)
    }

    /**
     * Gets the currently active AI provider.
     */
    suspend fun getActiveProvider(): AiProvider {
        val settings = settingsRepository.getSettings().firstOrNull()
        val providerName = settings?.aiProvider ?: "gemini"

        return when (providerName) {
            "openai" -> openAiProvider
            else -> geminiProvider
        }
    }

    /**
     * Gets a provider by name.
     */
    fun getProvider(name: String): AiProvider? = when (name) {
        "gemini" -> geminiProvider
        "openai" -> openAiProvider
        else -> null
    }

    /**
     * Checks if the active provider is configured.
     */
    suspend fun isActiveProviderConfigured(): Boolean {
        return getActiveProvider().isConfigured()
    }

    /**
     * Validates the API key for the active provider.
     */
    suspend fun validateActiveKey(): Boolean {
        return getActiveProvider().validateApiKey()
    }

    /**
     * Gets available models for the active provider.
     */
    suspend fun getAvailableModels(): List<String> {
        return getActiveProvider().availableModels
    }

    companion object {
        private const val TAG = "AiEngine"
    }
}
