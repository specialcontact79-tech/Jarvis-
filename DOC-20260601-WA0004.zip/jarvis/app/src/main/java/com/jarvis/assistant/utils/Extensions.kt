package com.jarvis.assistant.utils

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Formats an Instant to a relative time string (e.g., "2 min ago").
 */
fun Instant.toRelativeTime(): String {
    val now = Instant.now()
    val seconds = now.epochSecond - this.epochSecond

    return when {
        seconds < 60 -> "Just now"
        seconds < 3600 -> "${seconds / 60} min ago"
        seconds < 86400 -> "${seconds / 3600} hr ago"
        seconds < 604800 -> "${seconds / 86400} days ago"
        else -> DateTimeFormatter.ofPattern("MMM d, yyyy")
            .withZone(ZoneId.systemDefault())
            .format(this)
    }
}

/**
 * Formats an Instant to a time string (e.g., "2:30 PM").
 */
fun Instant.toTimeString(): String {
    return DateTimeFormatter.ofPattern("h:mm a")
        .withZone(ZoneId.systemDefault())
        .format(this)
}

/**
 * Formats an Instant to a date string (e.g., "Jan 15, 2024").
 */
fun Instant.toDateString(): String {
    return DateTimeFormatter.ofPattern("MMM d, yyyy")
        .withZone(ZoneId.systemDefault())
        .format(this)
}

/**
 * Formats an Instant to a date-time string.
 */
fun Instant.toDateTimeString(): String {
    return DateTimeFormatter.ofPattern("MMM d, yyyy 'at' h:mm a")
        .withZone(ZoneId.systemDefault())
        .format(this)
}

/**
 * Truncates a string to a maximum length with ellipsis.
 */
fun String.truncate(maxLength: Int): String {
    return if (length > maxLength) {
        take(maxLength - 3) + "..."
    } else this
}

/**
 * Capitalizes the first letter of each word.
 */
fun String.toTitleCase(): String {
    return split(" ")
        .joinToString(" ") { word ->
            word.replaceFirstChar {
                if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
            }
        }
}

/**
 * Checks if a string contains any of the given keywords.
 */
fun String.containsAny(keywords: List<String>, ignoreCase: Boolean = true): Boolean {
    return keywords.any { this.contains(it, ignoreCase) }
}
