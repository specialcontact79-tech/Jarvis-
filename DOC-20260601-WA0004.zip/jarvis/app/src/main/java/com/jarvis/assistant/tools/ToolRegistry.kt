package com.jarvis.assistant.tools

import com.jarvis.assistant.utils.Logger
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Registry for all available tools.
 *
 * Manages tool registration and lookup.
 */
@Singleton
class ToolRegistry @Inject constructor(
    private val appTool: AppTool,
    private val settingsTool: SettingsTool,
    private val deviceTool: DeviceTool,
    private val communicationTool: CommunicationTool,
    private val mediaTool: MediaTool
) {

    private val tools = mutableMapOf<String, Tool>()

    init {
        registerDefaultTools()
    }

    private fun registerDefaultTools() {
        // App control tools
        register(appTool)
        register(settingsTool)

        // Device control tools
        register(deviceTool)

        // Communication tools
        register(communicationTool)

        // Media tools
        register(mediaTool)

        Logger.i(TAG, "Registered ${tools.size} tools")
    }

    /**
     * Registers a tool in the registry.
     */
    fun register(tool: Tool) {
        tools[tool.getName()] = tool
        Logger.i(TAG, "Registered tool: ${tool.getName()}")
    }

    /**
     * Finds a tool by name.
     */
    fun findTool(name: String): Tool? = tools[name]

    /**
     * Gets all registered tools.
     */
    fun getAllTools(): List<Tool> = tools.values.toList()

    /**
     * Gets the number of registered tools.
     */
    fun getToolCount(): Int = tools.size

    companion object {
        private const val TAG = "ToolRegistry"
    }
}
