package com.jarvis.assistant.presentation.theme

import androidx.compose.ui.graphics.Color

// JARVIS Brand Colors
val JarvisBlue = Color(0xFF00D4FF)
val JarvisBlueDark = Color(0xFF0099CC)
val JarvisBlueLight = Color(0xFF80E5FF)
val JarvisBlueGlow = Color(0x3300D4FF)

val JarvisPurple = Color(0xFF7B61FF)
val JarvisPurpleDark = Color(0xFF5A3FD1)
val JarvisPurpleLight = Color(0xFFA694FF)

val JarvisCyan = Color(0xFF00E5FF)
val JarvisTeal = Color(0xFF00BFA5)
val JarvisGreen = Color(0xFF00E676)
val JarvisRed = Color(0xFFFF5252)
val JarvisOrange = Color(0xFFFFAB40)
val JarvisYellow = Color(0xFFFFFF00)

// Dark Theme Surface Colors
val SurfaceDark = Color(0xFF0A0A0F)
val SurfaceDarkElevated = Color(0xFF12121A)
val SurfaceDarkOverlay = Color(0xFF1A1A24)
val SurfaceCard = Color(0xFF151520)
val SurfaceCardElevated = Color(0xFF1E1E2E)

// Light Theme Surface Colors
val SurfaceLight = Color(0xFFF8F9FA)
val SurfaceLightElevated = Color(0xFFFFFFFF)
val SurfaceLightCard = Color(0xFFF1F3F4)

// Text Colors
val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFFB0B0B8)
val TextTertiaryDark = Color(0xFF707078)
val TextDisabledDark = Color(0xFF505058)

val TextPrimaryLight = Color(0xFF1A1A24)
val TextSecondaryLight = Color(0xFF5A5A68)
val TextTertiaryLight = Color(0xFF8A8A98)
val TextDisabledLight = Color(0xFFB0B0B8)

// Status Colors
val StatusSuccess = Color(0xFF00E676)
val StatusWarning = Color(0xFFFFAB40)
val StatusError = Color(0xFFFF5252)
val StatusInfo = Color(0xFF448AFF)
val StatusListening = Color(0xFF00D4FF)
val StatusProcessing = Color(0xFF7B61FF)
val StatusSpeaking = Color(0xFF00E5FF)

// Gradients
val GradientStart = Color(0xFF00D4FF)
val GradientEnd = Color(0xFF7B61FF)
