package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.domain.model.AppSettings
import com.jarvis.assistant.domain.usecase.ManageSettingsUseCase
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Settings screen.
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val manageSettingsUseCase: ManageSettingsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    val settings: StateFlow<AppSettings> =
        manageSettingsUseCase.getSettings()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun updateAiProvider(provider: String) {
        viewModelScope.launch {
            try {
                manageSettingsUseCase.updateAiProvider(provider)
                _uiState.update { it.copy(successMessage = "AI provider updated") }
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to update provider", e)
                _uiState.update { it.copy(errorMessage = "Failed to update provider") }
            }
        }
    }

    fun saveApiKey(provider: String, apiKey: String) {
        viewModelScope.launch {
            try {
                manageSettingsUseCase.saveApiKey(provider, apiKey)
                _uiState.update { it.copy(successMessage = "API key saved securely") }
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to save API key", e)
                _uiState.update { it.copy(errorMessage = "Failed to save API key") }
            }
        }
    }

    fun updateThemeMode(mode: String) {
        viewModelScope.launch {
            try {
                manageSettingsUseCase.updateThemeMode(mode)
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to update theme", e)
            }
        }
    }

    fun updateWakeWord(enabled: Boolean, sensitivity: String) {
        viewModelScope.launch {
            try {
                manageSettingsUseCase.updateWakeWordSettings(enabled, sensitivity)
                _uiState.update { it.copy(successMessage = "Wake word settings updated") }
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to update wake word", e)
                _uiState.update { it.copy(errorMessage = "Failed to update wake word settings") }
            }
        }
    }

    fun updateVoiceSettings(language: String, speed: Float, pitch: Float) {
        viewModelScope.launch {
            try {
                manageSettingsUseCase.updateVoiceSettings(language, speed, pitch)
                _uiState.update { it.copy(successMessage = "Voice settings updated") }
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to update voice settings", e)
            }
        }
    }

    fun updateHandsFreeMode(enabled: Boolean) {
        viewModelScope.launch {
            try {
                manageSettingsUseCase.updateHandsFreeMode(enabled)
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to update hands-free mode", e)
            }
        }
    }

    fun updateAutoSaveMemories(enabled: Boolean) {
        viewModelScope.launch {
            try {
                manageSettingsUseCase.updateAutoSaveMemories(enabled)
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to update auto-save", e)
            }
        }
    }

    fun resetToDefaults() {
        viewModelScope.launch {
            try {
                manageSettingsUseCase.resetToDefaults()
                _uiState.update { it.copy(successMessage = "Settings reset to defaults") }
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to reset settings", e)
                _uiState.update { it.copy(errorMessage = "Failed to reset settings") }
            }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(successMessage = null, errorMessage = null) }
    }

    data class SettingsUiState(
        val successMessage: String? = null,
        val errorMessage: String? = null,
        val isLoading: Boolean = false
    )

    companion object {
        private const val TAG = "SettingsViewModel"
    }
}
