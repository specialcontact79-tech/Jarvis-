package com.jarvis.assistant.di

import android.app.Application
import android.content.Context
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.room.Room
import com.jarvis.assistant.ai.AiEngine
import com.jarvis.assistant.ai.AiProvider
import com.jarvis.assistant.ai.GeminiProvider
import com.jarvis.assistant.ai.OpenAiProvider
import com.jarvis.assistant.data.local.db.JarvisDatabase
import com.jarvis.assistant.data.local.prefs.SecurePrefsManager
import com.jarvis.assistant.data.repository.ConversationRepository
import com.jarvis.assistant.data.repository.MemoryRepository
import com.jarvis.assistant.data.repository.SettingsRepository
import com.jarvis.assistant.domain.repository.ConversationRepositoryInterface
import com.jarvis.assistant.domain.repository.MemoryRepositoryInterface
import com.jarvis.assistant.domain.repository.SettingsRepositoryInterface
import com.jarvis.assistant.domain.usecase.ManageMemoryUseCase
import com.jarvis.assistant.domain.usecase.ManageSettingsUseCase
import com.jarvis.assistant.domain.usecase.ProcessVoiceCommandUseCase
import com.jarvis.assistant.domain.usecase.SendMessageUseCase
import com.jarvis.assistant.voice.SpeechRecognizerManager
import com.jarvis.assistant.voice.TextToSpeechManager
import com.jarvis.assistant.voice.WakeWordDetector
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import javax.inject.Qualifier
import javax.inject.Singleton

/**
 * Qualifier for IO dispatcher.
 */
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class IoDispatcher

/**
 * Qualifier for Main dispatcher.
 */
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MainDispatcher

/**
 * Qualifier for Application scope.
 */
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class ApplicationScope

/**
 * Hilt DI Module for JARVIS application.
 *
 * Provides all singleton dependencies across the application lifecycle.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    // ==================== DISPATCHERS ====================

    @Provides
    @Singleton
    @IoDispatcher
    fun provideIoDispatcher(): CoroutineDispatcher = Dispatchers.IO

    @Provides
    @Singleton
    @MainDispatcher
    fun provideMainDispatcher(): CoroutineDispatcher = Dispatchers.Main

    @Provides
    @Singleton
    @ApplicationScope
    fun provideApplicationScope(
        @IoDispatcher ioDispatcher: CoroutineDispatcher
    ): CoroutineScope = CoroutineScope(SupervisorJob() + ioDispatcher)

    // ==================== DATABASE ====================

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context
    ): JarvisDatabase = Room.databaseBuilder(
        context,
        JarvisDatabase::class.java,
        "jarvis_database.db"
    )
        .fallbackToDestructiveMigration()
        .build()

    @Provides
    @Singleton
    fun provideConversationDao(db: JarvisDatabase) = db.conversationDao()

    @Provides
    @Singleton
    fun provideMemoryDao(db: JarvisDatabase) = db.memoryDao()

    @Provides
    @Singleton
    fun provideSettingsDao(db: JarvisDatabase) = db.settingsDao()

    // ==================== OKHTTP ====================

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(
            HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
        )
        .build()

    // ==================== SECURITY ====================

    @Provides
    @Singleton
    fun provideSecurePrefsManager(
        @ApplicationContext context: Context
    ): SecurePrefsManager = SecurePrefsManager(context)

    // ==================== VOICE ====================

    @Provides
    @Singleton
    fun provideSpeechRecognizerManager(
        @ApplicationContext context: Context
    ): SpeechRecognizerManager = SpeechRecognizerManager(context)

    @Provides
    @Singleton
    fun provideTextToSpeechManager(
        @ApplicationContext context: Context
    ): TextToSpeechManager = TextToSpeechManager(context)

    @Provides
    @Singleton
    fun provideWakeWordDetector(
        @ApplicationContext context: Context,
        speechRecognizerManager: SpeechRecognizerManager
    ): WakeWordDetector = WakeWordDetector(context, speechRecognizerManager)

    // ==================== AI PROVIDERS ====================

    @Provides
    @Singleton
    fun provideGeminiProvider(
        okHttpClient: OkHttpClient,
        securePrefsManager: SecurePrefsManager
    ): GeminiProvider = GeminiProvider(okHttpClient, securePrefsManager)

    @Provides
    @Singleton
    fun provideOpenAiProvider(
        okHttpClient: OkHttpClient,
        securePrefsManager: SecurePrefsManager
    ): OpenAiProvider = OpenAiProvider(okHttpClient, securePrefsManager)

    @Provides
    @Singleton
    fun provideAiEngine(
        geminiProvider: GeminiProvider,
        openAiProvider: OpenAiProvider,
        settingsRepository: SettingsRepositoryInterface
    ): AiEngine = AiEngine(geminiProvider, openAiProvider, settingsRepository)

    // ==================== REPOSITORIES ====================

    @Provides
    @Singleton
    fun provideConversationRepository(
        db: JarvisDatabase,
        @IoDispatcher dispatcher: CoroutineDispatcher
    ): ConversationRepositoryInterface = ConversationRepository(db, dispatcher)

    @Provides
    @Singleton
    fun provideMemoryRepository(
        db: JarvisDatabase,
        @IoDispatcher dispatcher: CoroutineDispatcher
    ): MemoryRepositoryInterface = MemoryRepository(db, dispatcher)

    @Provides
    @Singleton
    fun provideSettingsRepository(
        db: JarvisDatabase,
        securePrefsManager: SecurePrefsManager,
        @IoDispatcher dispatcher: CoroutineDispatcher
    ): SettingsRepositoryInterface = SettingsRepository(db, securePrefsManager, dispatcher)

    // ==================== USE CASES ====================

    @Provides
    @Singleton
    fun provideSendMessageUseCase(
        aiEngine: AiEngine,
        conversationRepository: ConversationRepositoryInterface,
        memoryRepository: MemoryRepositoryInterface
    ): SendMessageUseCase = SendMessageUseCase(aiEngine, conversationRepository, memoryRepository)

    @Provides
    @Singleton
    fun provideProcessVoiceCommandUseCase(
        sendMessageUseCase: SendMessageUseCase,
        textToSpeechManager: TextToSpeechManager
    ): ProcessVoiceCommandUseCase = ProcessVoiceCommandUseCase(sendMessageUseCase, textToSpeechManager)

    @Provides
    @Singleton
    fun provideManageMemoryUseCase(
        memoryRepository: MemoryRepositoryInterface
    ): ManageMemoryUseCase = ManageMemoryUseCase(memoryRepository)

    @Provides
    @Singleton
    fun provideManageSettingsUseCase(
        settingsRepository: SettingsRepositoryInterface
    ): ManageSettingsUseCase = ManageSettingsUseCase(settingsRepository)
}
