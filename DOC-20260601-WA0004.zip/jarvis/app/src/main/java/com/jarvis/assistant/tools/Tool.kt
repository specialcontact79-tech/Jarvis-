package com.jarvis.assistant.tools

import com.jarvis.assistant.ai.ToolDefinition

/**
 * Base interface for all device control tools.
 *
 * Each tool implements this interface to provide:
 * - Tool definition for AI function calling
 * - Parameter extraction from natural language
 * - Tool execution logic
 */
interface Tool {

    /**
     * Unique name of the tool (used in function calling).
     */
    fun getName(): String

    /**
     * Human-readable description of what the tool does.
     */
    fun getDescription(): String

    /**
     * Returns the tool definition for AI function calling registration.
     */
    fun getDefinition(): ToolDefinition

    /**
     * Executes the tool by parsing parameters from natural language input.
     *
     * @param input Natural language user input
     * @return Result description of the execution
     */
    suspend fun execute(input: String): String

    /**
     * Executes the tool with pre-extracted parameters.
     *
     * @param params Map of parameter names to values
     * @return Result description of the execution
     */
    suspend fun executeWithParams(params: Map<String, String>): String
}
