package com.jarvis.assistant.utils

/**
 * Application constants.
 */
object Constants {

    // App
    const val APP_NAME = "JARVIS"
    const val APP_VERSION = "1.0.0"

    // AI
    const val DEFAULT_AI_PROVIDER = "gemini"
    const val DEFAULT_AI_MODEL = "gemini-pro"
    const val DEFAULT_SYSTEM_PROMPT = "You are JARVIS, a helpful AI assistant. Be concise but helpful."
    const val MAX_CONVERSATION_HISTORY = 20

    // Voice
    const val DEFAULT_LANGUAGE = "en-US"
    const val DEFAULT_SPEECH_SPEED = 1.0f
    const val DEFAULT_SPEECH_PITCH = 1.0f

    // Wake Word
    const val WAKE_WORD_HEY_JARVIS = "hey jarvis"
    const val WAKE_WORD_JARVIS = "jarvis"
    const val DEFAULT_WAKE_WORD_SENSITIVITY = "medium"

    // Memory
    const val SHORT_TERM_MEMORY_HOURS = 24L
    const val MAX_SHORT_TERM_MEMORIES = 50
    const val MAX_LONG_TERM_MEMORIES = 200

    // Network
    const val API_TIMEOUT_SECONDS = 30L
    const val MAX_RETRIES = 3

    // Database
    const val DATABASE_NAME = "jarvis_database"
    const val DATABASE_VERSION = 1

    // Preferences
    const val PREFS_SETTINGS = "jarvis_settings"
    const val PREFS_SECURE = "jarvis_secure_prefs"

    // Debounce
    const val SEARCH_DEBOUNCE_MS = 300L
    const val CLICK_DEBOUNCE_MS = 300L
}
