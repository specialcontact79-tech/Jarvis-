package com.jarvis.assistant.data.repository

import com.jarvis.assistant.data.local.db.JarvisDatabase
import com.jarvis.assistant.data.local.entity.SettingsEntity
import com.jarvis.assistant.data.local.prefs.SecurePrefsManager
import com.jarvis.assistant.domain.model.AiConfig
import com.jarvis.assistant.domain.model.AppSettings
import com.jarvis.assistant.domain.repository.SettingsRepositoryInterface
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for managing user settings.
 */
@Singleton
class SettingsRepository @Inject constructor(
    private val db: JarvisDatabase,
    private val securePrefsManager: SecurePrefsManager,
    private val dispatcher: CoroutineDispatcher
) : SettingsRepositoryInterface {

    override fun getSettings(): Flow<AppSettings> =
        db.settingsDao().getSettings()
            .map { entity ->
                (entity ?: createDefaultSettingsEntity()).toDomain()
            }

    override suspend fun getSettingsSync(): AppSettings =
        withContext(dispatcher) {
            (db.settingsDao().getSettingsSync() ?: createDefaultSettingsEntity()).toDomain()
        }

    override suspend fun updateAiProvider(provider: String) =
        withContext(dispatcher) {
            ensureSettingsExist()
            db.settingsDao().updateAiProvider(provider)
        }

    override suspend fun updateAiModel(model: String) =
        withContext(dispatcher) {
            ensureSettingsExist()
            db.settingsDao().updateAiModel(model)
        }

    override suspend fun updateThemeMode(mode: String) =
        withContext(dispatcher) {
            ensureSettingsExist()
            db.settingsDao().updateThemeMode(mode)
        }

    override suspend fun updateWakeWordSettings(enabled: Boolean, sensitivity: String) =
        withContext(dispatcher) {
            ensureSettingsExist()
            db.settingsDao().updateWakeWordEnabled(enabled)
            db.settingsDao().updateWakeWordSensitivity(sensitivity)
        }

    override suspend fun updateVoiceSettings(language: String, speed: Float, pitch: Float) =
        withContext(dispatcher) {
            ensureSettingsExist()
            db.settingsDao().updateVoiceSettings(language, speed, pitch)
        }

    override suspend fun updateHandsFreeMode(enabled: Boolean) =
        withContext(dispatcher) {
            ensureSettingsExist()
            db.settingsDao().updateHandsFreeMode(enabled)
        }

    override suspend fun updateAutoSaveMemories(enabled: Boolean) =
        withContext(dispatcher) {
            ensureSettingsExist()
            db.settingsDao().updateAutoSaveMemories(enabled)
        }

    override suspend fun saveGeminiApiKey(apiKey: String) =
        withContext(dispatcher) {
            securePrefsManager.saveGeminiApiKey(apiKey)
        }

    override suspend fun saveOpenAiApiKey(apiKey: String) =
        withContext(dispatcher) {
            securePrefsManager.saveOpenAiApiKey(apiKey)
        }

    override fun getGeminiApiKey(): String? = securePrefsManager.getGeminiApiKey()

    override fun getOpenAiApiKey(): String? = securePrefsManager.getOpenAiApiKey()

    override fun hasAnyApiKey(): Boolean = securePrefsManager.hasAnyApiKey()

    override suspend fun getAiConfig(): AiConfig =
        withContext(dispatcher) {
            val settings = db.settingsDao().getSettingsSync()
            val provider = settings?.aiProvider ?: "gemini"
            val geminiKey = securePrefsManager.getGeminiApiKey()
            val openAiKey = securePrefsManager.getOpenAiApiKey()

            AiConfig(
                provider = provider,
                geminiApiKey = geminiKey,
                openAiApiKey = openAiKey,
                model = settings?.aiModel ?: when (provider) {
                    "gemini" -> "gemini-pro"
                    "openai" -> "gpt-4"
                    else -> "gemini-pro"
                }
            )
        }

    override suspend fun resetToDefaults() =
        withContext(dispatcher) {
            val default = createDefaultSettingsEntity()
            db.settingsDao().insertSettings(default)
        }

    // ==================== PRIVATE ====================

    private suspend fun ensureSettingsExist() {
        if (db.settingsDao().getSettingsSync() == null) {
            db.settingsDao().insertSettings(createDefaultSettingsEntity())
        }
    }

    private fun createDefaultSettingsEntity() = SettingsEntity(
        id = 1,
        aiProvider = "gemini",
        aiModel = "gemini-pro",
        voiceLanguage = "en-US",
        voiceSpeed = 1.0f,
        voicePitch = 1.0f,
        wakeWordEnabled = false,
        wakeWordSensitivity = "medium",
        themeMode = "system",
        handsFreeMode = false,
        conversationHistoryEnabled = true,
        autoSaveMemories = true,
        lastUpdated = Instant.now()
    )

    // ==================== MAPPERS ====================

    private fun SettingsEntity.toDomain() = AppSettings(
        aiProvider = aiProvider,
        aiModel = aiModel,
        voiceLanguage = voiceLanguage,
        voiceSpeed = voiceSpeed,
        voicePitch = voicePitch,
        wakeWordEnabled = wakeWordEnabled,
        wakeWordSensitivity = wakeWordSensitivity,
        themeMode = themeMode,
        handsFreeMode = handsFreeMode,
        conversationHistoryEnabled = conversationHistoryEnabled,
        autoSaveMemories = autoSaveMemories
    )
}
