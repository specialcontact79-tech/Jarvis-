package com.jarvis.assistant.ai

import com.jarvis.assistant.data.local.prefs.SecurePrefsManager
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.utils.Logger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Google Gemini AI provider implementation.
 */
@Singleton
class GeminiProvider @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val securePrefsManager: SecurePrefsManager
) : AiProvider {

    private val json = Json { ignoreUnknownKeys = true }

    override val name: String = "gemini"

    override val availableModels: List<String> = listOf(
        "gemini-pro",
        "gemini-1.5-pro-latest",
        "gemini-1.5-flash-latest"
    )

    override fun isConfigured(): Boolean =
        !securePrefsManager.getGeminiApiKey().isNullOrBlank()

    override suspend fun validateApiKey(): Boolean {
        val apiKey = securePrefsManager.getGeminiApiKey() ?: return false
        return try {
            val request = buildRequest(
                apiKey = apiKey,
                body = GeminiRequest(
                    contents = listOf(
                        GeminiContent(
                            parts = listOf(GeminiPart(text = "Say OK"))
                        )
                    ),
                    generationConfig = GeminiGenerationConfig(maxOutputTokens = 10)
                )
            )
            okHttpClient.newCall(request).execute().use { response ->
                response.isSuccessful
            }
        } catch (e: Exception) {
            Logger.e(TAG, "API key validation failed", e)
            false
        }
    }

    override fun sendMessage(
        messages: List<ChatMessage>,
        systemPrompt: String,
        tools: List<ToolDefinition>
    ): Flow<AiResponse> = flow {
        val apiKey = securePrefsManager.getGeminiApiKey()
        if (apiKey.isNullOrBlank()) {
            emit(AiResponse.Error("Gemini API key not configured"))
            return@flow
        }

        try {
            val geminiTools = if (tools.isNotEmpty()) {
                listOf(
                    GeminiTool(
                        functionDeclarations = tools.map { tool ->
                            GeminiFunctionDeclaration(
                                name = tool.name,
                                description = tool.description,
                                parameters = tool.parameters
                            )
                        }
                    )
                )
            } else null

            val geminiContents = buildGeminiContents(messages, systemPrompt)

            val request = buildRequest(
                apiKey = apiKey,
                body = GeminiRequest(
                    contents = geminiContents,
                    tools = geminiTools,
                    toolConfig = if (geminiTools != null) {
                        GeminiToolConfig(
                            functionCallingConfig = GeminiFunctionCallingConfig("AUTO")
                        )
                    } else null,
                    generationConfig = GeminiGenerationConfig()
                )
            )

            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string()
                    Logger.e(TAG, "Gemini API error: $errorBody")
                    emit(AiResponse.Error("API error: ${response.code}"))
                    return@flow
                }

                val responseBody = response.body?.string()
                    ?: run {
                        emit(AiResponse.Error("Empty response"))
                        return@flow
                    }

                val geminiResponse = json.decodeFromString<GeminiResponse>(responseBody)

                // Check for API errors
                geminiResponse.error?.let { error ->
                    emit(AiResponse.Error("${error.message} (${error.code})"))
                    return@flow
                }

                // Check for blocked prompt
                geminiResponse.promptFeedback?.blockReason?.let { reason ->
                    emit(AiResponse.Error("Response blocked: $reason"))
                    return@flow
                }

                // Process candidates
                val candidate = geminiResponse.candidates?.firstOrNull()
                val content = candidate?.content

                // Check for function calls (tool calls)
                val functionCalls = content?.parts?.mapNotNull { it.functionCall }
                if (!functionCalls.isNullOrEmpty()) {
                    val toolCalls = functionCalls.map { fc ->
                        ToolCall(
                            id = "${fc.name}_${System.currentTimeMillis()}",
                            name = fc.name,
                            arguments = fc.args.entries.associate { it.key to it.value.toString() }
                        )
                    }
                    emit(AiResponse.ToolCallResponse(toolCalls))
                    return@flow
                }

                // Extract text response
                val text = content?.parts?.mapNotNull { it.text }?.joinToString("")
                if (!text.isNullOrBlank()) {
                    emit(AiResponse.Complete(text.trim()))
                } else {
                    emit(AiResponse.Error("Empty response from AI"))
                }
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Error in Gemini request", e)
            emit(AiResponse.Error(e.localizedMessage ?: "Unknown error"))
        }
    }

    private fun buildGeminiContents(
        messages: List<ChatMessage>,
        systemPrompt: String
    ): List<GeminiContent> {
        val contents = mutableListOf<GeminiContent>()

        // Add system prompt as first user message (Gemini doesn't have system role)
        if (systemPrompt.isNotBlank()) {
            contents.add(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = "System: $systemPrompt"))
                )
            )
            // Add model acknowledgment
            contents.add(
                GeminiContent(
                    role = "model",
                    parts = listOf(GeminiPart(text = "Understood. I'll follow these instructions."))
                )
            )
        }

        // Convert conversation history
        messages.forEach { message ->
            val role = when (message.role) {
                "user" -> "user"
                "assistant" -> "model"
                else -> "user"
            }
            contents.add(
                GeminiContent(
                    role = role,
                    parts = listOf(GeminiPart(text = message.content))
                )
            )
        }

        return contents
    }

    private fun buildRequest(apiKey: String, body: GeminiRequest): Request {
        val jsonBody = json.encodeToString(body)
        return Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=$apiKey")
            .post(jsonBody.toRequestBody("application/json".toMediaType()))
            .header("Content-Type", "application/json")
            .build()
    }

    companion object {
        private const val TAG = "GeminiProvider"
    }
}
