package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.domain.model.Memory
import com.jarvis.assistant.domain.usecase.ManageMemoryUseCase
import com.jarvis.assistant.utils.Logger
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Memory screen.
 */
@HiltViewModel
class MemoryViewModel @Inject constructor(
    private val manageMemoryUseCase: ManageMemoryUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(MemoryUiState())
    val uiState: StateFlow<MemoryUiState> = _uiState.asStateFlow()

    val allMemories: StateFlow<List<Memory>> =
        manageMemoryUseCase.getAllMemories()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shortTermMemories: StateFlow<List<Memory>> =
        manageMemoryUseCase.getShortTermMemories()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val longTermMemories: StateFlow<List<Memory>> =
        manageMemoryUseCase.getLongTermMemories()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addMemory(content: String, category: String = "fact", isLongTerm: Boolean = false) {
        viewModelScope.launch {
            try {
                val type = if (isLongTerm) "long_term" else "short_term"
                manageMemoryUseCase.addMemory(content, category, type)
                _uiState.update { it.copy(successMessage = "Memory saved") }
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to add memory", e)
                _uiState.update { it.copy(errorMessage = "Failed to save memory") }
            }
        }
    }

    fun deleteMemory(memoryId: String) {
        viewModelScope.launch {
            try {
                manageMemoryUseCase.deleteMemory(memoryId)
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to delete memory", e)
            }
        }
    }

    fun searchMemories(query: String) {
        viewModelScope.launch {
            if (query.isBlank()) return@launch
            try {
                val results = manageMemoryUseCase.searchMemories(query)
                _uiState.update { it.copy(searchResults = results) }
            } catch (e: Exception) {
                Logger.e(TAG, "Search failed", e)
            }
        }
    }

    fun cleanupExpiredMemories() {
        viewModelScope.launch {
            try {
                manageMemoryUseCase.cleanupExpiredMemories()
                _uiState.update { it.copy(successMessage = "Expired memories cleaned up") }
            } catch (e: Exception) {
                Logger.e(TAG, "Cleanup failed", e)
            }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(successMessage = null, errorMessage = null) }
    }

    data class MemoryUiState(
        val searchResults: List<Memory> = emptyList(),
        val successMessage: String? = null,
        val errorMessage: String? = null,
        val isLoading: Boolean = false
    )

    companion object {
        private const val TAG = "MemoryViewModel"
    }
}
